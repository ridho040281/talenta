<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminSettingsController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BadmintonMatchController;
use App\Http\Controllers\CertificateController;
use App\Http\Controllers\CollectiveRegistrationController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\JuriController;
use App\Http\Controllers\OfficialReportController;
use App\Http\Controllers\PesertaController;
use App\Http\Controllers\PicController;
use App\Http\Controllers\StageController;
use App\Http\Controllers\TournamentBracketController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public Routes
|--------------------------------------------------------------------------
*/
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/lomba/{slug}', [HomeController::class, 'competitionDetail'])->name('competition.detail');
Route::get('/lomba/{slug}/spin-viewer', [HomeController::class, 'spinViewer'])->name('spin.viewer');
// Short URL aliases for Smart TV / Proyektor (Mudah diketik di remote TV)
Route::get('/u/{slug}', [HomeController::class, 'spinViewer'])->name('spin.viewer.u');
Route::get('/tv/{slug}', [HomeController::class, 'spinViewer'])->name('spin.viewer.tv');
Route::get('/undi/{slug}', [HomeController::class, 'spinViewer'])->name('spin.viewer.undi');

// Tournament Bracket Public & TV Display
Route::get('/bagan/{slug}', [TournamentBracketController::class, 'publicView'])->name('public.bracket');
Route::get('/b/{slug}', [TournamentBracketController::class, 'publicView'])->name('public.bracket.short');
Route::get('/tv-bagan/{slug}', [TournamentBracketController::class, 'publicView'])->name('public.bracket.tv');

// Stage Display / Layar Panggung & Stage Timer (Smart TV / Proyektor View)
Route::get('/stage/{slug}', [StageController::class, 'stageViewer'])->name('stage.viewer');
Route::get('/p/{slug}', [StageController::class, 'stageViewer'])->name('stage.viewer.short');
Route::get('/tv-panggung/{slug}', [StageController::class, 'stageViewer'])->name('stage.viewer.tv');
Route::get('/panggung/{slug}', [StageController::class, 'stageViewer'])->name('stage.viewer.panggung');
Route::get('/stage/{slug}/state', [StageController::class, 'apiState'])->name('stage.api.state');

Route::get('/cek-status', [HomeController::class, 'checkStatus'])->name('check.status');
Route::get('/live-scoreboard/{slug?}', [HomeController::class, 'liveScoreboard'])->name('live.scoreboard');
Route::get('/skor/{slug?}', [HomeController::class, 'liveScoreboard'])->name('live.scoreboard.short');
Route::get('/api/leaderboard/{slug}', [HomeController::class, 'apiLeaderboard'])->name('api.leaderboard');
Route::get('/badminton/scoreboard/{id?}', [BadmintonMatchController::class, 'scoreboard'])->name('badminton.scoreboard');
Route::get('/badminton/arena', [BadmintonMatchController::class, 'arenaScoreboard'])->name('badminton.arena');
Route::get('/badminton/umpire/{id}', [BadmintonMatchController::class, 'umpire'])->name('badminton.umpire');
Route::get('/badminton/matches/{id}/state', [BadmintonMatchController::class, 'apiState'])->name('badminton.api.state');
Route::get('/badminton/matches/{id}/stream', [BadmintonMatchController::class, 'streamState'])->name('badminton.api.stream');
Route::post('/badminton/matches/{id}/score', [BadmintonMatchController::class, 'apiScore'])->name('badminton.api.score');
Route::get('/badminton/api/active-courts', [BadmintonMatchController::class, 'apiActiveCourts'])->name('badminton.api.active_courts');
Route::get('/badminton/api/arena-stream', [BadmintonMatchController::class, 'arenaStream'])->name('badminton.api.arena_stream');
Route::get('/verifikasi-sertifikat/{code}', [CertificateController::class, 'verifyPublic'])->name('certificate.verify');

Route::get('/bersihkan-cache', function () {
    Artisan::call('optimize:clear');
    return response('<div style="font-family:sans-serif;text-align:center;padding:50px;"><h1>✅ Cache Server Berhasil Dibersihkan!</h1><p>Silakan buka kembali halaman papan skor / verifikasi, lalu tekan <b>Ctrl + F5</b> (atau <b>Ctrl + Shift + R</b>) untuk melihat perubahan terbaru.</p></div>');
});

/*
|--------------------------------------------------------------------------
| Authentication Routes
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
    Route::get('/refresh-captcha', [AuthController::class, 'refreshCaptcha'])->name('captcha.refresh');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');
});
Route::get('/bukti-akun', [AuthController::class, 'showRegisterSuccess'])->name('register.success')->middleware('auth');
Route::post('/password/update', [AuthController::class, 'updatePassword'])->name('user.password.update')->middleware('auth');
Route::any('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

/*
|--------------------------------------------------------------------------
| Peserta (Pendaftar / Kontingen) Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:peserta,superadmin'])->prefix('peserta')->name('peserta.')->group(function () {
    Route::get('/dashboard', [PesertaController::class, 'dashboard'])->name('dashboard');
    Route::get('/pendaftaran-saya', [PesertaController::class, 'myRegistrations'])->name('registrations');
    Route::get('/daftar/{slug}', [PesertaController::class, 'showRegisterCompetition'])->name('register.competition');
    Route::post('/daftar/{slug}', [PesertaController::class, 'storeRegistration'])->name('register.competition.store');
    Route::get('/pendaftaran/{id}', [PesertaController::class, 'showRegistrationDetail'])->name('registration.detail');
    Route::post('/pendaftaran/{id}/revisi', [PesertaController::class, 'updateRevision'])->name('registration.revision');
    Route::get('/pendaftaran/{id}/cetak-kartu', [PesertaController::class, 'printIdCard'])->name('print.idcard');
    Route::get('/pendaftaran/{id}/kartu', [PesertaController::class, 'printIdCard'])->name('card');
    Route::get('/pendaftaran/{id}/sertifikat', [CertificateController::class, 'pesertaDownload'])->name('certificate.download');

    // Collective Registration (Excel) & Invoices
    Route::get('/collective', [CollectiveRegistrationController::class, 'wizard'])->name('collective.wizard');
    Route::get('/collective/template', [CollectiveRegistrationController::class, 'downloadTemplate'])->name('collective.template');
    Route::match(['get', 'post'], '/collective/parse', [CollectiveRegistrationController::class, 'parseExcel'])->name('collective.parse');
    Route::match(['get', 'post'], '/collective/confirm', [CollectiveRegistrationController::class, 'confirmBatch'])->name('collective.confirm');
    Route::get('/invoices/{id}', [CollectiveRegistrationController::class, 'showInvoice'])->name('invoices.show');
    Route::post('/invoices/{id}/upload-proof', [CollectiveRegistrationController::class, 'uploadPaymentProof'])->name('invoices.upload');
    Route::post('/invoices/{id}/upload-document', [CollectiveRegistrationController::class, 'uploadCollectiveDocument'])->name('invoices.upload_document');
});

/*
|--------------------------------------------------------------------------
| Dokumen Administrasi Cetak (Peserta & Panitia)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])->prefix('dokumen')->name('document.')->group(function () {
    Route::get('/bukti-akun/{registration_id}', [DocumentController::class, 'printAccountProof'])->name('print.account');
    Route::get('/bukti-pendaftaran/{registration_id}', [DocumentController::class, 'printRegistrationForm'])->name('print.registration');
    Route::get('/kwitansi/{registration_id}', [DocumentController::class, 'printReceipt'])->name('print.receipt');
    Route::get('/cetak-semua-bukti', [DocumentController::class, 'printCollectiveRegistrations'])->name('print.collective');
});

/*
|--------------------------------------------------------------------------
| PIC Cabang Lomba Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:pic_lomba,superadmin,panitia,admin'])->prefix('pic')->name('pic.')->group(function () {
    Route::get('/dashboard', [PicController::class, 'dashboard'])->name('dashboard');
    Route::get('/lomba/{competition_id}/peserta', [PicController::class, 'participants'])->name('participants');
    Route::get('/peserta/cetak-pdf', [PicController::class, 'printParticipantsPdf'])->name('participants.print.pdf');
    Route::get('/peserta/export-excel', [PicController::class, 'exportParticipantsExcel'])->name('participants.export.excel');
    Route::post('/peserta/store-manual', [PicController::class, 'storeParticipant'])->name('store.participant');
    Route::post('/peserta/{registration_id}/verifikasi', [PicController::class, 'verifyParticipant'])->name('verify.participant');
    Route::post('/peserta/{registration_id}/update', [PicController::class, 'updateParticipantData'])->name('update.participant');
    Route::post('/peserta/{registration_id}/batalkan-verifikasi', [PicController::class, 'unverifyParticipant'])->name('unverify.participant');
    Route::post('/peserta/{registration_id}/hapus', [PicController::class, 'deleteParticipant'])->name('delete.participant');
    Route::get('/peserta/{id}/download-photos', [PicController::class, 'downloadPhotos'])->name('participants.download_photos');
    Route::get('/undi-peserta', [PicController::class, 'drawIndex'])->name('undian');
    Route::get('/lomba/{competition_id}/undi', [PicController::class, 'hackerDraw'])->name('hacker.draw');
    Route::get('/lomba/{competition_id}/spin-wheel', [PicController::class, 'spinWheel'])->name('spin.wheel');
    Route::post('/lomba/{competition_id}/spin-wheel/save', [PicController::class, 'storeDrawResult'])->name('spin.wheel.save');
    Route::post('/lomba/{competition_id}/batch-draw', [PicController::class, 'batchAutoDraw'])->name('batch.draw');
    Route::post('/lomba/{competition_id}/spin-wheel/reset', [PicController::class, 'resetDraws'])->name('spin.wheel.reset');
    Route::post('/lomba/{competition_id}/set-seeded', [PicController::class, 'setSeededPlayers'])->name('set.seeded');

    // API endpoints untuk AJAX DataTable (server-side pagination)
    Route::get('/api/participants', [PicController::class, 'apiParticipants'])->name('api.participants');
    Route::get('/api/participants/{id}', [PicController::class, 'apiParticipantDetail'])->name('api.participant.detail');

    // Stage Timer & Layar Panggung Operator Control
    Route::get('/lomba/{competition_id}/stage-control', [StageController::class, 'operatorPanel'])->name('stage.control');
    Route::post('/lomba/{competition_id}/stage-control/action', [StageController::class, 'handleAction'])->name('stage.control.action');
    Route::post('/lomba/{competition_id}/stage-control/reset-all', [StageController::class, 'resetAllStage'])->name('stage.control.reset_all');

    // Berita Acara Lomba
    Route::get('/berita-acara', [OfficialReportController::class, 'index'])->name('berita-acara.index');
    Route::get('/berita-acara/cetak', [OfficialReportController::class, 'print'])->name('berita-acara.print');
});

/*
|--------------------------------------------------------------------------
| Tournament Bracket (Bagan Pertandingan BWF & Sistem Gugur)
| Akses Terpadu untuk PIC Lomba, Superadmin, Panitia, dan Dewan Juri/Wasit
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:pic_lomba,superadmin,panitia,juri'])->group(function () {
    Route::get('/pic/lomba/{competition_id}/bagan', [TournamentBracketController::class, 'show'])->name('pic.bracket');
    Route::get('/pic/lomba/{competition_id}/bagan/print', [TournamentBracketController::class, 'printPdf'])->name('pic.bracket.print');
    Route::post('/pic/lomba/{competition_id}/bagan/generate-matches', [TournamentBracketController::class, 'generateMatches'])->name('pic.bracket.generate_matches');
    Route::post('/pic/lomba/{competition_id}/bagan/update-schedule', [TournamentBracketController::class, 'updateMatchSchedule'])->name('pic.bracket.update_schedule');
    Route::post('/pic/lomba/{competition_id}/bagan/save-format', [TournamentBracketController::class, 'saveBracketFormat'])->name('pic.bracket.save_format');
});

/*
|--------------------------------------------------------------------------
| Dewan Juri Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:juri,superadmin'])->prefix('juri')->name('juri.')->group(function () {
    Route::get('/dashboard', [JuriController::class, 'dashboard'])->name('dashboard');
    Route::get('/lomba/{competition_id}/scoring', [JuriController::class, 'scoringSheet'])->name('scoring');
    Route::post('/lomba/{competition_id}/peserta/{registration_id}/score', [JuriController::class, 'storeScore'])->name('score.store');
});

/*
|--------------------------------------------------------------------------
| Pertandingan Bulu Tangkis & Wasit Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:superadmin,panitia,pic_lomba,juri'])->prefix('badminton')->name('badminton.')->group(function () {
    Route::get('/matches', [BadmintonMatchController::class, 'index'])->name('index');
    Route::get('/bagan/{competition_id?}', [TournamentBracketController::class, 'badmintonShow'])->name('bracket');
    Route::post('/matches', [BadmintonMatchController::class, 'store'])->name('store');
    Route::post('/matches/{id}/update', [BadmintonMatchController::class, 'update'])->name('update');
    Route::post('/matches/{id}/delete', [BadmintonMatchController::class, 'destroy'])->name('destroy');
});

/*
|--------------------------------------------------------------------------
| Presensi / Daftar Hadir & QR Scanner Routes
| Akses Terpadu untuk Superadmin, Panitia, dan PIC Lomba
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:superadmin,panitia,pic_lomba,admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/daftar-hadir', [AttendanceController::class, 'index'])->name('attendance.index');
    Route::post('/daftar-hadir/scan', [AttendanceController::class, 'scan'])->name('attendance.scan');
    Route::post('/daftar-hadir/{id}/toggle', [AttendanceController::class, 'toggle'])->name('attendance.toggle');
    Route::get('/daftar-hadir/cetak', [AttendanceController::class, 'printReport'])->name('attendance.print');
});

/*
|--------------------------------------------------------------------------
| Admin & Panitia Shared Operational Routes (Overview, Operasional, Laporan)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:superadmin,panitia'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
    Route::get('/recap', [AdminController::class, 'recap'])->name('recap');
    Route::get('/rekap-nilai', [AdminController::class, 'recap'])->name('scores');
    Route::get('/api/recap-participants', [AdminController::class, 'apiRecapParticipants'])->name('api.recap_participants');
    Route::get('/api/recap-cashflow', [AdminController::class, 'apiRecapCashflow'])->name('api.recap_cashflow');
    Route::get('/api/recap-institutions', [AdminController::class, 'apiRecapInstitutions'])->name('api.recap_institutions');
    Route::get('/berita-acara', [OfficialReportController::class, 'index'])->name('berita-acara.index');
    Route::get('/berita-acara/cetak', [OfficialReportController::class, 'print'])->name('berita-acara.print');

    // Sertifikat & Piagam Kejuaraan
    Route::get('/sertifikat', [CertificateController::class, 'index'])->name('certificates.index');
    Route::get('/sertifikat/desainer/{id?}', [CertificateController::class, 'designer'])->name('certificates.designer');
    Route::post('/sertifikat/template', [CertificateController::class, 'storeOrUpdateTemplate'])->name('certificates.template.store');
    Route::post('/sertifikat/template/{id}/layout', [CertificateController::class, 'saveLayout'])->name('certificates.template.layout');
    Route::post('/sertifikat/template/{id}/delete', [CertificateController::class, 'deleteTemplate'])->name('certificates.template.delete');
    Route::post('/sertifikat/toggle-release', [CertificateController::class, 'toggleRelease'])->name('certificates.toggle-release');
    Route::get('/sertifikat/cetak', [CertificateController::class, 'printSingle'])->name('certificates.print');
    Route::get('/sertifikat/cetak-massal', [CertificateController::class, 'printBulk'])->name('certificates.print.bulk');

    // Operational & Competition Routes (Data Peserta, Juri, Wasit & Undian)
    Route::get('/verifikasi', [PicController::class, 'dashboard'])->name('verifications');
    Route::get('/peserta', [PicController::class, 'dashboard'])->name('participants.index');
    Route::get('/peserta/{id}/download-photos', [PicController::class, 'downloadPhotos'])->name('participants.download_photos');
    Route::get('/peserta-multi-lomba', [AdminController::class, 'multiParticipants'])->name('participants.multi');
    Route::get('/juri-wasit', [AdminController::class, 'juriWasitUndian'])->name('juri.wasit');
    Route::get('/undi-peserta', [PicController::class, 'drawIndex'])->name('undian');

    // Invoice & Payment Verification Routes
    Route::get('/invoices', [CollectiveRegistrationController::class, 'adminInvoices'])->name('invoices.index');
    Route::get('/invoices/{id}', [CollectiveRegistrationController::class, 'adminShowInvoice'])->name('invoices.show');
    Route::post('/invoices/{id}/verify', [CollectiveRegistrationController::class, 'adminVerifyInvoice'])->name('invoices.verify');

    // Finance Adjustments & Refund Routes
    Route::post('/finance/adjustments', [AdminController::class, 'storePaymentAdjustment'])->name('finance.adjustments.store');
    Route::post('/finance/adjustments/{id}/delete', [AdminController::class, 'deletePaymentAdjustment'])->name('finance.adjustments.delete');
});

/*
|--------------------------------------------------------------------------
| Strictly Super Admin Only Routes (Master Data & Pengaturan Sistem)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:superadmin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/competitions', [AdminController::class, 'competitions'])->name('competitions');
    Route::post('/competitions', [AdminController::class, 'storeCompetition'])->name('competitions.store');
    Route::get('/competitions/{id}/edit', [AdminController::class, 'editCompetitionPage'])->name('competitions.edit');
    Route::post('/competitions/{id}/update', [AdminController::class, 'updateCompetition'])->name('competitions.update');
    Route::post('/competitions/{id}/delete', [AdminController::class, 'deleteCompetition'])->name('competitions.delete');
    Route::post('/competitions/{id}/toggle-live-score', [AdminController::class, 'toggleLiveScore'])->name('competitions.toggle-live-score');
    Route::post('/competitions/toggle-all-status', [AdminController::class, 'toggleAllCompetitionsStatus'])->name('competitions.toggle-all-status');

    // Category Routes
    Route::post('/categories', [AdminController::class, 'storeCategory'])->name('categories.store');
    Route::post('/categories/{id}/update', [AdminController::class, 'updateCategory'])->name('categories.update');
    Route::post('/categories/{id}/delete', [AdminController::class, 'deleteCategory'])->name('categories.delete');

    // Timeline Routes
    Route::post('/timeline', [AdminController::class, 'storeTimeline'])->name('timeline.store');
    Route::post('/timeline/{id}/update', [AdminController::class, 'updateTimeline'])->name('timeline.update');
    Route::post('/timeline/{id}/delete', [AdminController::class, 'deleteTimeline'])->name('timeline.delete');

    // Master Data: Kelola Pengguna
    Route::get('/users', [AdminController::class, 'users'])->name('users');
    Route::post('/users', [AdminController::class, 'storeUser'])->name('users.store');
    Route::post('/users/{id}/update', [AdminController::class, 'updateUser'])->name('users.update');
    Route::post('/users/{id}/reset-password', [AdminController::class, 'resetPassword'])->name('users.reset-password');
    Route::post('/users/{id}/delete', [AdminController::class, 'deleteUser'])->name('users.delete');

    // Settings Routes
    Route::prefix('settings')->name('settings.')->group(function () {
        Route::get('/general', [AdminSettingsController::class, 'generalSettings'])->name('general');
        Route::post('/general', [AdminSettingsController::class, 'updateGeneralSettings'])->name('general.update');
        Route::post('/sponsor-logo/upload', [AdminSettingsController::class, 'uploadSponsorLogos'])->name('sponsor.upload');
        Route::post('/sponsor-logo/delete', [AdminSettingsController::class, 'deleteSingleSponsorLogo'])->name('sponsor.delete');
        Route::post('/sponsor-logo/reorder', [AdminSettingsController::class, 'reorderSponsorLogos'])->name('sponsor.reorder');
        Route::post('/pamphlet-image/upload', [AdminSettingsController::class, 'uploadPamphletImages'])->name('pamphlet.upload');
        Route::post('/pamphlet-image/delete', [AdminSettingsController::class, 'deleteSinglePamphletImage'])->name('pamphlet.delete');
        Route::post('/clean-broken-media', [AdminSettingsController::class, 'cleanBrokenMedia'])->name('clean_broken_media');
        Route::post('/activity_logs/clear', [AdminSettingsController::class, 'clearActivityLogs'])->name('activity_logs.clear');
        Route::get('/whatsapp-blast', [AdminSettingsController::class, 'whatsappBlast'])->name('whatsapp.blast');
        Route::get('/whatsapp-blast/check-status', [AdminSettingsController::class, 'checkWablasStatus'])->name('whatsapp.blast.check-status');
        Route::get('/whatsapp-blast/template', [AdminSettingsController::class, 'downloadWhatsappTemplate'])->name('whatsapp.blast.template');
        Route::post('/whatsapp-blast', [AdminSettingsController::class, 'sendWhatsappBlast'])->name('whatsapp.blast.send');
        Route::post('/whatsapp-blast/logs/{id}/delete', [AdminSettingsController::class, 'deleteBroadcastLog'])->name('whatsapp.blast.logs.delete');
        Route::post('/whatsapp-blast/logs/clear-all', [AdminSettingsController::class, 'clearAllBroadcastLogs'])->name('whatsapp.blast.logs.clear-all');
        Route::post('/whatsapp-blast/contacts', [AdminSettingsController::class, 'storeCustomContact'])->name('whatsapp.blast.contacts.store');
        Route::post('/whatsapp-blast/contacts/{id}/delete', [AdminSettingsController::class, 'deleteCustomContact'])->name('whatsapp.blast.contacts.delete');
        Route::post('/whatsapp-blast/contacts/clear-all', [AdminSettingsController::class, 'clearAllCustomContacts'])->name('whatsapp.blast.contacts.clear-all');
        Route::post('/whatsapp-blast/templates', [AdminSettingsController::class, 'storeWhatsappTemplate'])->name('whatsapp.blast.templates.store');
        Route::get('/whatsapp-blast/templates/create', [AdminSettingsController::class, 'createWhatsappTemplatePage'])->name('whatsapp.blast.templates.create');
        Route::get('/whatsapp-blast/templates/{id}/edit', [AdminSettingsController::class, 'editWhatsappTemplatePage'])->name('whatsapp.blast.templates.edit');
        Route::post('/whatsapp-blast/templates/{id}/update', [AdminSettingsController::class, 'updateWhatsappTemplate'])->name('whatsapp.blast.templates.update');
        Route::post('/whatsapp-blast/templates/{id}/delete', [AdminSettingsController::class, 'deleteWhatsappTemplate'])->name('whatsapp.blast.templates.delete');
        Route::post('/whatsapp-blast/templates/{id}/toggle', [AdminSettingsController::class, 'toggleWhatsappTemplate'])->name('whatsapp.blast.templates.toggle');
        Route::post('/whatsapp-blast/save-credentials', [AdminSettingsController::class, 'saveWablasCredentials'])->name('whatsapp.blast.save-credentials');
        Route::post('/whatsapp-blast/test-connection', [AdminSettingsController::class, 'testWablasConnection'])->name('whatsapp.blast.test-connection');
        Route::post('/whatsapp-blast/test-send', [AdminSettingsController::class, 'testSendWhatsappMessage'])->name('whatsapp.blast.test-send');

        // Pop-up Announcement Modal Routes
        Route::get('/popup-announcement', [AdminSettingsController::class, 'popupAnnouncement'])->name('popup.index');
        Route::post('/popup-announcement', [AdminSettingsController::class, 'updatePopupAnnouncement'])->name('popup.update');
        Route::post('/popup-announcement/toggle', [AdminSettingsController::class, 'togglePopupAnnouncement'])->name('popup.toggle');
        Route::post('/popup-announcement/reset-version', [AdminSettingsController::class, 'resetPopupVersion'])->name('popup.reset-version');
        Route::post('/popup-announcement/history/{id}/delete', [AdminSettingsController::class, 'deletePopupHistory'])->name('popup.history.delete');

        Route::get('/changelog', [AdminSettingsController::class, 'changelog'])->name('changelog');
        Route::get('/app-info', [AdminSettingsController::class, 'appInfo'])->name('app.info');
    });
});

// Direct Dynamic Media Serving Fallback (Protects against symlink or server permissions issues)
Route::get('/storage/{folder}/{filename}', function ($folder, $filename) {
    $allowedFolders = [
        'documents', 'payments', 'payment_proofs', 'sponsors', 'pamphlets', 'popups',
        'settings', 'guidelines', 'certificates', 'avatars', 'qrcodes', 'invoices', 'adjustments',
    ];
    if (! in_array($folder, $allowedFolders)) {
        abort(404);
    }
    $cleanFilename = basename($filename);
    $path = storage_path("app/public/{$folder}/{$cleanFilename}");
    if (! file_exists($path)) {
        $path = public_path("storage/{$folder}/{$cleanFilename}");
    }
    if (file_exists($path)) {
        $mime = mime_content_type($path) ?: 'application/octet-stream';
        $disposition = in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'svg', 'gif']) ? 'inline' : 'attachment';

        return response()->file($path, [
            'Content-Type' => $mime,
            'Content-Disposition' => "{$disposition}; filename=\"{$cleanFilename}\"",
            'Cache-Control' => 'public, max-age=86400',
        ]);
    }
    abort(404);
})->where('filename', '[A-Za-z0-9_\-\.]+');

// Quick Route to Clear Views & Caches (Bisa diakses dari browser)
Route::get('/bersihkan-cache', function () {
    Artisan::call('view:clear');
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('route:clear');

    return response('
        <div style="font-family:sans-serif;padding:40px;text-align:center;background:#0f172a;color:#f8fafc;min-height:100vh;">
            <div style="background:#1e293b;max-width:500px;margin:50px auto;padding:30px;border-radius:16px;box-shadow:0 10px 25px rgba(0,0,0,0.5);border:1px solid #334155;">
                <h2 style="color:#4ade80;margin-top:0;">✅ Cache Berhasil Dibersihkan!</h2>
                <p style="color:#94a3b8;font-size:14px;line-height:1.6;">Cache View Blade, Route, dan Config Laravel telah di-refresh dengan sukses ke versi terbaru.</p>
                <div style="margin-top:24px;">
                    <a href="javascript:history.back()" style="display:inline-block;padding:10px 20px;background:#3b82f6;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold;font-size:14px;">Kembali ke Halaman Sebelumnya</a>
                </div>
            </div>
        </div>
    ');
})->name('system.clear-cache');

<?php

namespace App\Http\Controllers;

use App\Models\AppSetting;
use App\Models\BadmintonMatch;
use App\Models\Competition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class BadmintonMatchController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        if (! $user->managesBadminton()) {
            abort(403, 'Halaman ini khusus untuk koordinator dan wasit cabang Bulu Tangkis.');
        }

        $query = BadmintonMatch::with(['competition', 'umpire'])->latest();

        if ($request->filled('court')) {
            $query->where('court_number', $request->court);
        }

        if ($request->filled('status')) {
            $query->where('match_status', $request->status);
        }

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        $matches = $query->paginate(15);
        $competitions = Competition::where('code', 'BLT')->orWhere('name', 'like', '%Bulu Tangkis%')->orWhere('name', 'like', '%Badminton%')->get();
        if ($competitions->isEmpty()) {
            $competitions = Competition::all();
        }

        $courts = BadmintonMatch::select('court_number')->distinct()->pluck('court_number');
        if ($courts->isEmpty()) {
            $courts = collect(['Lapangan 1', 'Lapangan 2', 'Lapangan 3']);
        }

        return view('badminton.index', compact('matches', 'competitions', 'courts'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'competition_id' => 'nullable|exists:competitions,id',
            'court_number' => 'required|string|max:50',
            'match_code' => 'nullable|string|max:50',
            'round_name' => 'required|string|max:100',
            'category' => 'required|string|in:MS,WS,MD,WD,XD',
            'match_type' => 'required|string|in:single,double',
            'team1_school' => 'required|string|max:150',
            'team1_player1' => 'required|string|max:150',
            'team1_player2' => 'nullable|string|max:150',
            'team2_school' => 'required|string|max:150',
            'team2_player1' => 'required|string|max:150',
            'team2_player2' => 'nullable|string|max:150',
        ]);

        $validated['current_set'] = 1;
        $validated['team1_set1'] = 0;
        $validated['team2_set1'] = 0;
        $validated['team1_set2'] = 0;
        $validated['team2_set2'] = 0;
        $validated['team1_set3'] = 0;
        $validated['team2_set3'] = 0;
        $validated['server_team'] = 1;
        $validated['server_player'] = 1;
        $validated['match_status'] = 'upcoming';
        $validated['scores_history'] = [];

        $match = BadmintonMatch::create($validated);

        return redirect()->route('badminton.index')->with('success', "Pertandingan {$match->match_code} ({$match->court_number}) berhasil dibuat!");
    }

    public function update(Request $request, $id)
    {
        $match = BadmintonMatch::findOrFail($id);

        $validated = $request->validate([
            'competition_id' => 'nullable|exists:competitions,id',
            'court_number' => 'required|string|max:50',
            'match_code' => 'nullable|string|max:50',
            'round_name' => 'required|string|max:100',
            'category' => 'required|string|in:MS,WS,MD,WD,XD',
            'match_type' => 'required|string|in:single,double',
            'team1_school' => 'required|string|max:150',
            'team1_player1' => 'required|string|max:150',
            'team1_player2' => 'nullable|string|max:150',
            'team2_school' => 'required|string|max:150',
            'team2_player1' => 'required|string|max:150',
            'team2_player2' => 'nullable|string|max:150',
        ]);

        $match->update($validated);

        return redirect()->route('badminton.index')->with('success', 'Data pertandingan berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $match = BadmintonMatch::findOrFail($id);
        $match->delete();

        return redirect()->route('badminton.index')->with('success', 'Pertandingan berhasil dihapus.');
    }

    public function umpire($id)
    {
        $match = BadmintonMatch::with('competition')->findOrFail($id);
        $appSettings = AppSetting::getAllSettings();

        // Assign current user as umpire if not set
        if (! $match->umpire_id && Auth::check()) {
            $match->update(['umpire_id' => Auth::id()]);
        }

        return view('badminton.umpire', compact('match', 'appSettings'));
    }

    public function apiScore(Request $request, $id)
    {
        $match = BadmintonMatch::findOrFail($id);
        $action = $request->input('action');

        $history = $match->scores_history ?? [];

        // Save snapshot for Undo
        if (in_array($action, ['add_point', 'set_server', 'next_set', 'set_status'])) {
            $snapshot = [
                'current_set' => $match->current_set,
                'team1_set1' => $match->team1_set1,
                'team2_set1' => $match->team2_set1,
                'team1_set2' => $match->team1_set2,
                'team2_set2' => $match->team2_set2,
                'team1_set3' => $match->team1_set3,
                'team2_set3' => $match->team2_set3,
                'server_team' => $match->server_team,
                'server_player' => $match->server_player,
                'match_status' => $match->match_status,
                'winner_team' => $match->winner_team,
            ];
            $history[] = $snapshot;
            if (count($history) > 40) {
                array_shift($history);
            }
        }

        if ($action === 'add_point') {
            $team = (int) $request->input('team');
            $set = $match->current_set;

            // Check if current set or match is already finished
            if ($match->match_status === 'finished' || $match->isCurrentSetFinished()) {
                return response()->json([
                    'success' => true,
                    'match' => $this->formatMatchState($match),
                    'message' => 'Set sudah selesai. Silakan klik Set Selanjutnya.',
                ]);
            }

            if ($match->match_status === 'upcoming' || $match->match_status === 'interval') {
                $match->match_status = 'ongoing';
                $match->interval_until = null;
                if (! $match->started_at) {
                    $match->started_at = now();
                }
            }

            // Increment score with cap of 30
            $t1Key = "team1_set{$set}";
            $t2Key = "team2_set{$set}";

            if ($team === 1) {
                if ($match->{$t1Key} < 30) {
                    $match->{$t1Key}++;
                }
                if ($match->match_type === 'double') {
                    if ($match->server_team === 1) {
                        $match->server_player = ($match->server_player === 1) ? 2 : 1;
                    } else {
                        $match->server_team = 1;
                        $match->server_player = ($match->{$t1Key} % 2 === 0) ? 1 : 2;
                    }
                } else {
                    $match->server_team = 1;
                    $match->server_player = 1;
                }
            } else {
                if ($match->{$t2Key} < 30) {
                    $match->{$t2Key}++;
                }
                if ($match->match_type === 'double') {
                    if ($match->server_team === 2) {
                        $match->server_player = ($match->server_player === 1) ? 2 : 1;
                    } else {
                        $match->server_team = 2;
                        $match->server_player = ($match->{$t2Key} % 2 === 0) ? 1 : 2;
                    }
                } else {
                    $match->server_team = 2;
                    $match->server_player = 1;
                }
            }

            // Check if game won
            $s1 = (int) $match->{$t1Key};
            $s2 = (int) $match->{$t2Key};
            if ((($s1 >= 21 || $s2 >= 21) && abs($s1 - $s2) >= 2) || max($s1, $s2) >= 30) {
                $setsWon = $match->getSetsWon();
                if ($setsWon['t1'] >= 2) {
                    $match->match_status = 'finished';
                    $match->winner_team = 1;
                    $match->finished_at = now();
                } elseif ($setsWon['t2'] >= 2) {
                    $match->match_status = 'finished';
                    $match->winner_team = 2;
                    $match->finished_at = now();
                }
            }

            $match->scores_history = $history;
            $match->save();
            $this->touchMatchTimestamp($match->id);
        } elseif ($action === 'start_interval') {
            $seconds = (int) $request->input('seconds', 60);
            $match->match_status = 'interval';
            $match->interval_until = now()->addSeconds($seconds);
            $match->scores_history = $history;
            $match->save();
            $this->touchMatchTimestamp($match->id);
        } elseif ($action === 'stop_interval') {
            $match->match_status = 'ongoing';
            $match->interval_until = null;
            $match->scores_history = $history;
            $match->save();
            $this->touchMatchTimestamp($match->id);
        } elseif ($action === 'undo') {
            if (! empty($history)) {
                $last = array_pop($history);
                $match->fill($last);
                $match->scores_history = $history;
                $match->save();
                $this->touchMatchTimestamp($match->id);
            }
        } elseif ($action === 'set_server') {
            $match->server_team = (int) $request->input('team');
            $match->server_player = (int) $request->input('player', 1);
            $match->scores_history = $history;
            $match->save();
            $this->touchMatchTimestamp($match->id);
        } elseif ($action === 'next_set') {
            if ($match->current_set < 3) {
                $match->current_set++;
                $match->server_team = 1;
                $match->server_player = 1;
                $match->match_status = 'ongoing';
                $match->scores_history = $history;
                $match->save();
                $this->touchMatchTimestamp($match->id);
            }
        } elseif ($action === 'set_status') {
            $match->match_status = $request->input('status');
            $match->scores_history = $history;
            $match->save();
            $this->touchMatchTimestamp($match->id);
        } elseif ($action === 'reset') {
            $match->current_set = 1;
            $match->team1_set1 = 0;
            $match->team2_set1 = 0;
            $match->team1_set2 = 0;
            $match->team2_set2 = 0;
            $match->team1_set3 = 0;
            $match->team2_set3 = 0;
            $match->server_team = 1;
            $match->server_player = 1;
            $match->match_status = 'upcoming';
            $match->winner_team = null;
            $match->scores_history = [];
            $match->save();
            $this->touchMatchTimestamp($match->id);
        }

        $this->syncPlayoffWinnerToMainBracket($match);

        return response()->json([
            'success' => true,
            'match' => $this->formatMatchState($match),
        ]);
    }

    /**
     * Stamp a lightweight cache key so SSE listeners detect changes instantly.
     */
    private function touchMatchTimestamp(int $matchId): void
    {
        $ts = microtime(true);
        Cache::put("blt_match_{$matchId}_ts", $ts, 300);   // single match
        Cache::put('blt_arena_ts', $ts, 300);              // arena (all courts)
    }

    public function apiState($id)
    {
        $match = BadmintonMatch::find($id);
        if (! $match) {
            return response()->json(['error' => 'Match not found'], 404);
        }

        return response()->json($this->formatMatchState($match))
            ->header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache')
            ->header('Expires', '0');
    }

    public function scoreboard(Request $request, $id = null)
    {
        $appSettings = AppSetting::getAllSettings();

        $match = null;
        if ($id) {
            $match = BadmintonMatch::with('competition')->find($id);
        }

        if (! $match) {
            // Find active ongoing match or latest match
            $match = BadmintonMatch::with('competition')
                ->where('match_status', 'ongoing')
                ->latest('updated_at')
                ->first();

            if (! $match) {
                $match = BadmintonMatch::with('competition')->latest()->first();
            }
        }

        $allMatches = BadmintonMatch::latest()->take(20)->get();

        return view('badminton.scoreboard', compact('match', 'allMatches', 'appSettings'));
    }

    public function arenaScoreboard(Request $request)
    {
        $appSettings = AppSetting::getAllSettings();

        // Get distinct courts
        $courts = BadmintonMatch::select('court_number')->distinct()->orderBy('court_number')->pluck('court_number');
        if ($courts->isEmpty()) {
            $courts = collect(['Lapangan 1', 'Lapangan 2']);
        }

        // Get the most relevant match for each court (ongoing first, then upcoming, then finished)
        $courtMatches = [];
        foreach ($courts as $court) {
            $m = BadmintonMatch::where('court_number', $court)
                ->whereIn('match_status', ['ongoing', 'interval'])
                ->latest('updated_at')
                ->first();

            if (! $m) {
                $m = BadmintonMatch::where('court_number', $court)
                    ->where('match_status', 'upcoming')
                    ->first();
            }

            if (! $m) {
                $m = BadmintonMatch::where('court_number', $court)
                    ->latest('updated_at')
                    ->first();
            }

            if ($m) {
                $courtMatches[$court] = $this->formatMatchState($m);
            }
        }

        return view('badminton.arena', compact('courts', 'courtMatches', 'appSettings'));
    }

    public function apiActiveCourts()
    {
        $courts = BadmintonMatch::select('court_number')->distinct()->orderBy('court_number')->pluck('court_number');
        if ($courts->isEmpty()) {
            $courts = collect(['Lapangan 1', 'Lapangan 2']);
        }
        $courtMatches = [];
        foreach ($courts as $court) {
            $m = BadmintonMatch::where('court_number', $court)
                ->whereIn('match_status', ['ongoing', 'interval'])
                ->latest('updated_at')
                ->first();

            if (! $m) {
                $m = BadmintonMatch::where('court_number', $court)
                    ->where('match_status', 'upcoming')
                    ->first();
            }

            if (! $m) {
                $m = BadmintonMatch::where('court_number', $court)
                    ->latest('updated_at')
                    ->first();
            }

            if ($m) {
                $courtMatches[$court] = $this->formatMatchState($m);
            }
        }

        return response()->json($courtMatches)
            ->header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache')
            ->header('Expires', '0');
    }

    /**
     * SSE stream untuk satu pertandingan (scoreboard single-court).
     * Browser connect sekali, server push saat skor berubah.
     * GET /badminton/matches/{id}/stream
     */
    public function streamState($id)
    {
        $match = BadmintonMatch::find($id);
        if (! $match) {
            return response()->json(['error' => 'Match not found'], 404);
        }

        $matchId = $match->id;
        $cacheKey = "blt_match_{$matchId}_ts";
        $lastTs = 0.0;
        $deadline = time() + 300; // max 5 menit per koneksi

        return response()->stream(function () use ($matchId, $cacheKey, &$lastTs, $deadline) {
            // Kirim state awal segera
            $m = BadmintonMatch::find($matchId);
            if ($m) {
                $payload = json_encode($this->formatMatchState($m));
                echo "event: score\n";
                echo "data: {$payload}\n\n";
                $lastTs = (float) Cache::get($cacheKey, 0);
            }
            ob_flush();
            flush();

            while (time() < $deadline && ! connection_aborted()) {
                usleep(300_000); // cek tiap 300ms

                $ts = (float) Cache::get($cacheKey, 0);
                if ($ts > $lastTs) {
                    $lastTs = $ts;
                    $m = BadmintonMatch::find($matchId);
                    if ($m) {
                        $payload = json_encode($this->formatMatchState($m));
                        echo "event: score\n";
                        echo "data: {$payload}\n\n";
                        ob_flush();
                        flush();
                    }
                }

                // Heartbeat tiap 15 detik agar proxy tidak putus koneksi
                if ((int) (microtime(true) * 1000) % 15000 < 300) {
                    echo ": heartbeat\n\n";
                    ob_flush();
                    flush();
                }
            }

            // Beri tahu client agar reconnect (SSE auto-reconnect dalam 1 detik)
            echo "event: reconnect\ndata: {}\n\n";
            ob_flush();
            flush();
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache, no-store',
            'X-Accel-Buffering' => 'no',  // nonaktifkan Nginx buffering
            'Connection' => 'keep-alive',
        ]);
    }

    /**
     * SSE stream untuk arena multi-lapangan.
     * GET /badminton/api/arena-stream
     */
    public function arenaStream()
    {
        $cacheKey = 'blt_arena_ts';
        $lastTs = 0.0;
        $deadline = time() + 300;

        return response()->stream(function () use ($cacheKey, &$lastTs, $deadline) {
            // Kirim state awal segera
            $payload = json_encode($this->buildArenaState());
            echo "event: arena\n";
            echo "data: {$payload}\n\n";
            $lastTs = (float) Cache::get($cacheKey, 0);
            ob_flush();
            flush();

            while (time() < $deadline && ! connection_aborted()) {
                usleep(300_000);

                $ts = (float) Cache::get($cacheKey, 0);
                if ($ts > $lastTs) {
                    $lastTs = $ts;
                    $payload = json_encode($this->buildArenaState());
                    echo "event: arena\n";
                    echo "data: {$payload}\n\n";
                    ob_flush();
                    flush();
                }

                if ((int) (microtime(true) * 1000) % 15000 < 300) {
                    echo ": heartbeat\n\n";
                    ob_flush();
                    flush();
                }
            }

            echo "event: reconnect\ndata: {}\n\n";
            ob_flush();
            flush();
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache, no-store',
            'X-Accel-Buffering' => 'no',
            'Connection' => 'keep-alive',
        ]);
    }

    /**
     * Build arena state (semua lapangan aktif).
     */
    private function buildArenaState(): array
    {
        $courts = BadmintonMatch::select('court_number')->distinct()->orderBy('court_number')->pluck('court_number');
        if ($courts->isEmpty()) {
            $courts = collect(['Lapangan 1', 'Lapangan 2']);
        }
        $courtMatches = [];
        foreach ($courts as $court) {
            $m = BadmintonMatch::where('court_number', $court)
                ->whereIn('match_status', ['ongoing', 'interval'])
                ->latest('updated_at')->first();
            if (! $m) {
                $m = BadmintonMatch::where('court_number', $court)->where('match_status', 'upcoming')->first();
            }
            if (! $m) {
                $m = BadmintonMatch::where('court_number', $court)->latest('updated_at')->first();
            }
            if ($m) {
                $courtMatches[$court] = $this->formatMatchState($m);
            }
        }

        return $courtMatches;
    }

    private function formatMatchState(BadmintonMatch $match): array
    {
        return [
            'id' => $match->id,
            'court_number' => $match->court_number,
            'match_code' => $match->match_code,
            'round_name' => $match->round_name,
            'category' => $match->category,
            'match_type' => $match->match_type,
            'team1_school' => $match->team1_school,
            'team1_player1' => $match->team1_player1,
            'team1_player2' => $match->team1_player2,
            'team2_school' => $match->team2_school,
            'team2_player1' => $match->team2_player1,
            'team2_player2' => $match->team2_player2,
            'current_set' => $match->current_set,
            'team1_set1' => $match->team1_set1,
            'team2_set1' => $match->team2_set1,
            'team1_set2' => $match->team1_set2,
            'team2_set2' => $match->team2_set2,
            'team1_set3' => $match->team1_set3,
            'team2_set3' => $match->team2_set3,
            'server_team' => $match->server_team,
            'server_player' => $match->server_player,
            'match_status' => $match->match_status,
            'winner_team' => $match->winner_team,
            'sets_won' => $match->getSetsWon(),
            'is_set_finished' => $match->isCurrentSetFinished(),
            'interval_until' => $match->interval_until?->toIso8601String(),
            'interval_remaining' => $match->interval_until ? max(0, (int) ceil(now()->diffInRealSeconds($match->interval_until, false))) : 0,
            'updated_at' => $match->updated_at?->toIso8601String() ?? now()->toIso8601String(),
        ];
    }

    private function syncPlayoffWinnerToMainBracket(BadmintonMatch $match): void
    {
        if (! preg_match('/^(.+)-PO-M(\d+)$/', $match->match_code, $m)) {
            return;
        }

        $poolKey = $m[1];
        $poNum = (int) $m[2];

        // In standard brackets, PO 1 feeds into the highest Match in Round 1 (Team 2)
        $targetR1Match = BadmintonMatch::where('competition_id', $match->competition_id)
            ->where('match_code', 'like', "{$poolKey}-R1-M%")
            ->orderByRaw('CAST(SUBSTRING_INDEX(match_code, "-M", -1) AS UNSIGNED) DESC')
            ->first();

        if (! $targetR1Match) {
            return;
        }

        if ($match->match_status === 'finished' && in_array($match->winner_team, [1, 2])) {
            $isT1 = ($match->winner_team === 1);
            $targetR1Match->team2_registration_id = $isT1 ? $match->team1_registration_id : $match->team2_registration_id;
            $targetR1Match->team2_player1 = $isT1 ? $match->team1_player1 : $match->team2_player1;
            $targetR1Match->team2_player2 = $isT1 ? $match->team1_player2 : $match->team2_player2;
            $targetR1Match->team2_school = $isT1 ? $match->team1_school : $match->team2_school;
            $targetR1Match->save();
            $this->touchMatchTimestamp($targetR1Match->id);
        } elseif (in_array($match->match_status, ['upcoming', 'ongoing', 'interval'])) {
            if ($targetR1Match->team2_player1 !== '[Pemenang Play-off]') {
                $targetR1Match->team2_registration_id = null;
                $targetR1Match->team2_player1 = '[Pemenang Play-off]';
                $targetR1Match->team2_player2 = null;
                $targetR1Match->team2_school = 'TBD';
                $targetR1Match->save();
                $this->touchMatchTimestamp($targetR1Match->id);
            }
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\AppSetting;
use App\Models\Category;
use App\Models\Competition;
use App\Models\DrawAllocation;
use App\Models\Invoice;
use App\Models\Registration;
use App\Models\RegistrationMember;
use App\Models\User;
use App\Services\ImageOptimizerService;
use App\Services\WablasNotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PicController extends Controller
{
    /**
     * Get IDs of all competitions managed by user (both as primary PIC and sector/category PIC in AppSetting)
     */
    public static function getManagedCompetitionIds($user): array
    {
        if (! $user) {
            return [];
        }

        if (in_array($user->role, ['superadmin', 'panitia', 'admin'])) {
            return Competition::pluck('id')->toArray();
        }

        $extraCodes = [];
        $bltPics = array_filter([
            AppSetting::get('blt_pic_tunggal_pa'),
            AppSetting::get('blt_pic_tunggal_pi'),
            AppSetting::get('blt_pic_ganda_pa'),
            AppSetting::get('blt_pic_ganda_pi'),
        ]);
        if (in_array($user->id, $bltPics) || in_array((string) $user->id, $bltPics)) {
            $extraCodes[] = 'BLT';
        }

        $tmjPics = array_filter([
            AppSetting::get('tmj_pic_tunggal_pa'),
            AppSetting::get('tmj_pic_tunggal_pi'),
        ]);
        if (in_array($user->id, $tmjPics) || in_array((string) $user->id, $tmjPics)) {
            $extraCodes[] = 'TMJ';
        }

        $mtqPics = array_filter([
            AppSetting::get('mtq_pic_pa'),
            AppSetting::get('mtq_pic_pi'),
        ]);
        if (in_array($user->id, $mtqPics) || in_array((string) $user->id, $mtqPics)) {
            $extraCodes[] = 'MTQ';
        }

        $popPics = array_filter([
            AppSetting::get('pop_pic_pa'),
            AppSetting::get('pop_pic_pi'),
        ]);
        if (in_array($user->id, $popPics) || in_array((string) $user->id, $popPics)) {
            $extraCodes[] = 'POP';
        }

        return Competition::where(function ($q) use ($user, $extraCodes) {
            $q->where('pic_id', $user->id)
                ->orWhereHas('pics', function ($sub) use ($user) {
                    $sub->where('users.id', $user->id);
                });
            if (! empty($extraCodes)) {
                $q->orWhereIn('code', $extraCodes);
            }
        })->pluck('id')->toArray();
    }

    protected function authorizeCompetitionManagement($user, $competitionId): void
    {
        if (! in_array($competitionId, self::getManagedCompetitionIds($user))) {
            abort(403, 'Anda tidak memiliki hak akses untuk mengelola cabang lomba ini.');
        }
    }

    public function dashboard(Request $request)
    {
        $user = Auth::user();
        $competitionIds = self::getManagedCompetitionIds($user);

        // Get competitions managed by this PIC (or all if superadmin)
        $competitions = Competition::with('category')
            ->whereIn('id', $competitionIds)
            ->get();

        $selectedCompId = $request->query('competition_id');

        // Jika tidak ada competition_id yang dipilih secara eksplisit:
        // Jika PIC hanya mengelola 1 cabor, arahkan langsung ke cabor tersebut
        if (! $selectedCompId && $user && $user->role === 'pic_lomba') {
            if (count($competitionIds) === 1) {
                $selectedCompId = (string) $competitionIds[0];
            } elseif ($user->managesBadminton()) {
                $bltComp = $competitions->first(fn ($c) => $c->code === 'BLT' || str_contains(strtolower($c->name), 'bulu tangkis'));
                if ($bltComp) {
                    $selectedCompId = (string) $bltComp->id;
                }
            }
        }

        // Ambil instance kompetisi aktif jika ada
        $activeCompetition = null;
        if ($selectedCompId && $selectedCompId !== 'all') {
            $activeCompetition = $competitions->firstWhere('id', (int) $selectedCompId)
                ?? Competition::with(['category', 'registrations.members'])->find($selectedCompId);
        }

        $statsCompIds = ($activeCompetition) ? [$activeCompetition->id] : $competitionIds;

        $statusCounts = Registration::whereIn('competition_id', $statsCompIds)
            ->selectRaw('status, count(*) as count')
            ->groupBy('status')
            ->pluck('count', 'status');

        $totalRegistrations = Registration::whereIn('competition_id', $statsCompIds)->count();

        $drawnCount = Registration::whereIn('competition_id', $statsCompIds)
            ->whereNotNull('draw_number')
            ->count();

        $totalPa = Registration::whereIn('competition_id', $statsCompIds)
            ->whereHas('members', fn ($q) => $q->where('gender', 'L'))
            ->count();

        $totalPi = Registration::whereIn('competition_id', $statsCompIds)
            ->whereHas('members', fn ($q) => $q->where('gender', 'P'))
            ->count();

        $stats = [
            'total_competitions' => $activeCompetition ? 1 : $competitions->count(),
            'total_registrations' => $totalRegistrations,
            'pending_verifications' => (int) ($statusCounts->get('pending', 0)),
            'pending_registrations' => (int) ($statusCounts->get('pending', 0)),
            'verified_registrations' => (int) ($statusCounts->get('verified', 0)),
            'revision_registrations' => (int) ($statusCounts->get('revision', 0)),
            'rejected_registrations' => (int) ($statusCounts->get('rejected', 0)),
            'drawn_participants' => $drawnCount,
            'total_pa' => $totalPa,
            'total_pi' => $totalPi,
        ];

        $categories = Category::all();

        // Pass competitionIds and active competition to view
        return view('pic.dashboard', compact(
            'user',
            'competitions',
            'stats',
            'categories',
            'competitionIds',
            'selectedCompId',
            'activeCompetition'
        ));
    }

    /**
     * API: Paginated participants list for AJAX DataTable
     * GET /pic/api/participants?competition_id=&status=&gender=&sector=&search=&page=&per_page=
     */
    public function apiParticipants(Request $request)
    {
        $user = Auth::user();
        $competitionIds = self::getManagedCompetitionIds($user);

        $query = Registration::with([
            'competition:id,name,code',
            'members:id,registration_id,full_name,gender,nisn,school_name,birth_place,birth_date',
            'invoice:id,invoice_number,status,payment_proof,final_amount',
        ])
            ->whereIn('competition_id', $competitionIds);

        // Filter competition
        if ($request->filled('competition_id') && $request->competition_id !== 'all') {
            $query->where('competition_id', $request->competition_id);
        }

        // Filter status
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        // Filter sector (target_class / match_type combos)
        if ($request->filled('sector') && $request->sector !== 'all') {
            $sector = $request->sector;
            switch ($sector) {
                case 'ganda':
                case 'ganda_all':
                    $query->where(function ($q) {
                        $q->where('match_type', 'LIKE', '%Ganda%')
                            ->orWhere('target_class', 'LIKE', '%Ganda%')
                            ->orWhere('sub_category', 'LIKE', '%Ganda%');
                    });
                    break;
                case 'ganda_pa':
                    $query->where(function ($q) {
                        $q->where('match_type', 'LIKE', '%Ganda%')
                            ->orWhere('target_class', 'LIKE', '%Ganda%')
                            ->orWhere('sub_category', 'LIKE', '%Ganda%');
                    })->whereHas('members', fn ($q) => $q->where('gender', 'L'));
                    break;
                case 'ganda_pi':
                    $query->where(function ($q) {
                        $q->where('match_type', 'LIKE', '%Ganda%')
                            ->orWhere('target_class', 'LIKE', '%Ganda%')
                            ->orWhere('sub_category', 'LIKE', '%Ganda%');
                    })->whereHas('members', fn ($q) => $q->where('gender', 'P'));
                    break;
                case 'tunggal_all':
                    $query->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->where('target_class', 'NOT LIKE', '%Ganda%')->orWhereNull('target_class');
                    });
                    break;
                case 'tunggal_pa':
                case 'individu_pa':
                    $query->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->where('target_class', 'NOT LIKE', '%Ganda%')->orWhereNull('target_class');
                    })->whereHas('members', fn ($q) => $q->where('gender', 'L'));
                    break;
                case 'tunggal_pi':
                case 'individu_pi':
                    $query->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->where('target_class', 'NOT LIKE', '%Ganda%')->orWhereNull('target_class');
                    })->whereHas('members', fn ($q) => $q->where('gender', 'P'));
                    break;
                case 'blt_a_all':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%1 - 2%')
                            ->orWhere('target_class', 'LIKE', '%1-2%')
                            ->orWhere('target_class', 'LIKE', '%1–2%')
                            ->orWhere('target_class', 'LIKE', '%Kategori A%')
                            ->orWhere('target_class', 'LIKE', '%Kat A%')
                            ->orWhere('target_class', 'LIKE', '%Kat_A%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 1%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 2%')
                            ->orWhere('sub_category', 'LIKE', '%1 - 2%')
                            ->orWhere('sub_category', 'LIKE', '%1-2%')
                            ->orWhere('sub_category', 'LIKE', '%1–2%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori A%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 1%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 2%')
                            ->orWhere('registration_code', 'LIKE', '%-A-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    });
                    break;
                case 'tunggal_pa_a':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%1 - 2%')
                            ->orWhere('target_class', 'LIKE', '%1-2%')
                            ->orWhere('target_class', 'LIKE', '%1–2%')
                            ->orWhere('target_class', 'LIKE', '%Kategori A%')
                            ->orWhere('target_class', 'LIKE', '%Kat A%')
                            ->orWhere('target_class', 'LIKE', '%Kat_A%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 1%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 2%')
                            ->orWhere('sub_category', 'LIKE', '%1 - 2%')
                            ->orWhere('sub_category', 'LIKE', '%1-2%')
                            ->orWhere('sub_category', 'LIKE', '%1–2%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori A%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 1%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 2%')
                            ->orWhere('registration_code', 'LIKE', '%-A-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'L'))
                            ->orWhere('match_type', 'LIKE', '%Putra%')
                            ->orWhere('match_type', 'LIKE', '%(PA)%');
                    });
                    break;
                case 'tunggal_pi_a':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%1 - 2%')
                            ->orWhere('target_class', 'LIKE', '%1-2%')
                            ->orWhere('target_class', 'LIKE', '%1–2%')
                            ->orWhere('target_class', 'LIKE', '%Kategori A%')
                            ->orWhere('target_class', 'LIKE', '%Kat A%')
                            ->orWhere('target_class', 'LIKE', '%Kat_A%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 1%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 2%')
                            ->orWhere('sub_category', 'LIKE', '%1 - 2%')
                            ->orWhere('sub_category', 'LIKE', '%1-2%')
                            ->orWhere('sub_category', 'LIKE', '%1–2%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori A%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 1%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 2%')
                            ->orWhere('registration_code', 'LIKE', '%-A-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'P'))
                            ->orWhere('match_type', 'LIKE', '%Putri%')
                            ->orWhere('match_type', 'LIKE', '%(PI)%');
                    });
                    break;
                case 'blt_b_all':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%3 - 4%')
                            ->orWhere('target_class', 'LIKE', '%3-4%')
                            ->orWhere('target_class', 'LIKE', '%3–4%')
                            ->orWhere('target_class', 'LIKE', '%Kategori B%')
                            ->orWhere('target_class', 'LIKE', '%Kat B%')
                            ->orWhere('target_class', 'LIKE', '%Kat_B%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 3%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 4%')
                            ->orWhere('sub_category', 'LIKE', '%3 - 4%')
                            ->orWhere('sub_category', 'LIKE', '%3-4%')
                            ->orWhere('sub_category', 'LIKE', '%3–4%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori B%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 3%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 4%')
                            ->orWhere('registration_code', 'LIKE', '%-B-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    });
                    break;
                case 'tunggal_pa_b':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%3 - 4%')
                            ->orWhere('target_class', 'LIKE', '%3-4%')
                            ->orWhere('target_class', 'LIKE', '%3–4%')
                            ->orWhere('target_class', 'LIKE', '%Kategori B%')
                            ->orWhere('target_class', 'LIKE', '%Kat B%')
                            ->orWhere('target_class', 'LIKE', '%Kat_B%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 3%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 4%')
                            ->orWhere('sub_category', 'LIKE', '%3 - 4%')
                            ->orWhere('sub_category', 'LIKE', '%3-4%')
                            ->orWhere('sub_category', 'LIKE', '%3–4%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori B%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 3%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 4%')
                            ->orWhere('registration_code', 'LIKE', '%-B-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'L'))
                            ->orWhere('match_type', 'LIKE', '%Putra%')
                            ->orWhere('match_type', 'LIKE', '%(PA)%');
                    });
                    break;
                case 'tunggal_pi_b':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%3 - 4%')
                            ->orWhere('target_class', 'LIKE', '%3-4%')
                            ->orWhere('target_class', 'LIKE', '%3–4%')
                            ->orWhere('target_class', 'LIKE', '%Kategori B%')
                            ->orWhere('target_class', 'LIKE', '%Kat B%')
                            ->orWhere('target_class', 'LIKE', '%Kat_B%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 3%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 4%')
                            ->orWhere('sub_category', 'LIKE', '%3 - 4%')
                            ->orWhere('sub_category', 'LIKE', '%3-4%')
                            ->orWhere('sub_category', 'LIKE', '%3–4%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori B%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 3%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 4%')
                            ->orWhere('registration_code', 'LIKE', '%-B-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'P'))
                            ->orWhere('match_type', 'LIKE', '%Putri%')
                            ->orWhere('match_type', 'LIKE', '%(PI)%');
                    });
                    break;
                case 'blt_c_all':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%5 - 6%')
                            ->orWhere('target_class', 'LIKE', '%5-6%')
                            ->orWhere('target_class', 'LIKE', '%5–6%')
                            ->orWhere('target_class', 'LIKE', '%Kategori C%')
                            ->orWhere('target_class', 'LIKE', '%Kat C%')
                            ->orWhere('target_class', 'LIKE', '%Kat_C%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 5%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 6%')
                            ->orWhere('sub_category', 'LIKE', '%5 - 6%')
                            ->orWhere('sub_category', 'LIKE', '%5-6%')
                            ->orWhere('sub_category', 'LIKE', '%5–6%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori C%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 5%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 6%')
                            ->orWhere('registration_code', 'LIKE', '%-C-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    });
                    break;
                case 'tunggal_pa_c':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%5 - 6%')
                            ->orWhere('target_class', 'LIKE', '%5-6%')
                            ->orWhere('target_class', 'LIKE', '%5–6%')
                            ->orWhere('target_class', 'LIKE', '%Kategori C%')
                            ->orWhere('target_class', 'LIKE', '%Kat C%')
                            ->orWhere('target_class', 'LIKE', '%Kat_C%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 5%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 6%')
                            ->orWhere('sub_category', 'LIKE', '%5 - 6%')
                            ->orWhere('sub_category', 'LIKE', '%5-6%')
                            ->orWhere('sub_category', 'LIKE', '%5–6%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori C%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 5%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 6%')
                            ->orWhere('registration_code', 'LIKE', '%-C-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'L'))
                            ->orWhere('match_type', 'LIKE', '%Putra%')
                            ->orWhere('match_type', 'LIKE', '%(PA)%');
                    });
                    break;
                case 'tunggal_pi_c':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%5 - 6%')
                            ->orWhere('target_class', 'LIKE', '%5-6%')
                            ->orWhere('target_class', 'LIKE', '%5–6%')
                            ->orWhere('target_class', 'LIKE', '%Kategori C%')
                            ->orWhere('target_class', 'LIKE', '%Kat C%')
                            ->orWhere('target_class', 'LIKE', '%Kat_C%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 5%')
                            ->orWhere('target_class', 'LIKE', '%Kelas 6%')
                            ->orWhere('sub_category', 'LIKE', '%5 - 6%')
                            ->orWhere('sub_category', 'LIKE', '%5-6%')
                            ->orWhere('sub_category', 'LIKE', '%5–6%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori C%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 5%')
                            ->orWhere('sub_category', 'LIKE', '%Kelas 6%')
                            ->orWhere('registration_code', 'LIKE', '%-C-%');
                    })->where(function ($q) {
                        $q->where('match_type', 'NOT LIKE', '%Ganda%')->orWhereNull('match_type');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'P'))
                            ->orWhere('match_type', 'LIKE', '%Putri%')
                            ->orWhere('match_type', 'LIKE', '%(PI)%');
                    });
                    break;
                case 'tmj_pa_a':
                case 'kat_a':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%1 - 3%')
                            ->orWhere('target_class', 'LIKE', '%1-3%')
                            ->orWhere('target_class', 'LIKE', '%1–3%')
                            ->orWhere('target_class', 'LIKE', '%Kategori A%')
                            ->orWhere('target_class', 'LIKE', '%Kat A%')
                            ->orWhere('target_class', 'LIKE', '%Kat_A%')
                            ->orWhere('sub_category', 'LIKE', '%1 - 3%')
                            ->orWhere('sub_category', 'LIKE', '%1-3%')
                            ->orWhere('sub_category', 'LIKE', '%1–3%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori A%')
                            ->orWhere('registration_code', 'LIKE', '%-A-%');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'L'))
                            ->orWhere('match_type', 'LIKE', '%Putra%')
                            ->orWhere('match_type', 'LIKE', '%(PA)%');
                    });
                    break;
                case 'tmj_pi_a':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%1 - 3%')
                            ->orWhere('target_class', 'LIKE', '%1-3%')
                            ->orWhere('target_class', 'LIKE', '%1–3%')
                            ->orWhere('target_class', 'LIKE', '%Kategori A%')
                            ->orWhere('target_class', 'LIKE', '%Kat A%')
                            ->orWhere('target_class', 'LIKE', '%Kat_A%')
                            ->orWhere('sub_category', 'LIKE', '%1 - 3%')
                            ->orWhere('sub_category', 'LIKE', '%1-3%')
                            ->orWhere('sub_category', 'LIKE', '%1–3%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori A%')
                            ->orWhere('registration_code', 'LIKE', '%-A-%');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'P'))
                            ->orWhere('match_type', 'LIKE', '%Putri%')
                            ->orWhere('match_type', 'LIKE', '%(PI)%');
                    });
                    break;
                case 'tmj_a_all':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%1 - 3%')
                            ->orWhere('target_class', 'LIKE', '%1-3%')
                            ->orWhere('target_class', 'LIKE', '%1–3%')
                            ->orWhere('target_class', 'LIKE', '%Kategori A%')
                            ->orWhere('target_class', 'LIKE', '%Kat A%')
                            ->orWhere('target_class', 'LIKE', '%Kat_A%')
                            ->orWhere('sub_category', 'LIKE', '%1 - 3%')
                            ->orWhere('sub_category', 'LIKE', '%1-3%')
                            ->orWhere('sub_category', 'LIKE', '%1–3%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori A%')
                            ->orWhere('registration_code', 'LIKE', '%-A-%');
                    });
                    break;
                case 'tmj_pa_b':
                case 'kat_b':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%4 - 6%')
                            ->orWhere('target_class', 'LIKE', '%4-6%')
                            ->orWhere('target_class', 'LIKE', '%4–6%')
                            ->orWhere('target_class', 'LIKE', '%Kategori B%')
                            ->orWhere('target_class', 'LIKE', '%Kat B%')
                            ->orWhere('target_class', 'LIKE', '%Kat_B%')
                            ->orWhere('sub_category', 'LIKE', '%4 - 6%')
                            ->orWhere('sub_category', 'LIKE', '%4-6%')
                            ->orWhere('sub_category', 'LIKE', '%4–6%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori B%')
                            ->orWhere('registration_code', 'LIKE', '%-B-%');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'L'))
                            ->orWhere('match_type', 'LIKE', '%Putra%')
                            ->orWhere('match_type', 'LIKE', '%(PA)%');
                    });
                    break;
                case 'tmj_pi_b':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%4 - 6%')
                            ->orWhere('target_class', 'LIKE', '%4-6%')
                            ->orWhere('target_class', 'LIKE', '%4–6%')
                            ->orWhere('target_class', 'LIKE', '%Kategori B%')
                            ->orWhere('target_class', 'LIKE', '%Kat B%')
                            ->orWhere('target_class', 'LIKE', '%Kat_B%')
                            ->orWhere('sub_category', 'LIKE', '%4 - 6%')
                            ->orWhere('sub_category', 'LIKE', '%4-6%')
                            ->orWhere('sub_category', 'LIKE', '%4–6%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori B%')
                            ->orWhere('registration_code', 'LIKE', '%-B-%');
                    })->where(function ($q) {
                        $q->whereHas('members', fn ($m) => $m->where('gender', 'P'))
                            ->orWhere('match_type', 'LIKE', '%Putri%')
                            ->orWhere('match_type', 'LIKE', '%(PI)%');
                    });
                    break;
                case 'tmj_b_all':
                    $query->where(function ($q) {
                        $q->where('target_class', 'LIKE', '%4 - 6%')
                            ->orWhere('target_class', 'LIKE', '%4-6%')
                            ->orWhere('target_class', 'LIKE', '%4–6%')
                            ->orWhere('target_class', 'LIKE', '%Kategori B%')
                            ->orWhere('target_class', 'LIKE', '%Kat B%')
                            ->orWhere('target_class', 'LIKE', '%Kat_B%')
                            ->orWhere('sub_category', 'LIKE', '%4 - 6%')
                            ->orWhere('sub_category', 'LIKE', '%4-6%')
                            ->orWhere('sub_category', 'LIKE', '%4–6%')
                            ->orWhere('sub_category', 'LIKE', '%Kategori B%')
                            ->orWhere('registration_code', 'LIKE', '%-B-%');
                    });
                    break;
                case 'rob_sumo':
                case 'sumo':
                    $query->where(function ($q) {
                        $q->where('sub_category', 'LIKE', '%Sumo%')
                            ->orWhere('match_type', 'LIKE', '%Sumo%')
                            ->orWhere('target_class', 'LIKE', '%Sumo%');
                    });
                    break;
                case 'rob_soccer':
                case 'soccer':
                    $query->where(function ($q) {
                        $q->where('sub_category', 'LIKE', '%Soccer%')
                            ->orWhere('match_type', 'LIKE', '%Soccer%')
                            ->orWhere('target_class', 'LIKE', '%Soccer%');
                    });
                    break;
                case 'rob_kreatif':
                case 'kreatif':
                    $query->where(function ($q) {
                        $q->where('sub_category', 'LIKE', '%Kreatif%')
                            ->orWhere('match_type', 'LIKE', '%Kreatif%')
                            ->orWhere('target_class', 'LIKE', '%Kreatif%');
                    });
                    break;
            }
        }

        // Full-text search
        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('registration_code', 'LIKE', "%{$s}%")
                    ->orWhere('institution_name', 'LIKE', "%{$s}%")
                    ->orWhere('official_name', 'LIKE', "%{$s}%")
                    ->orWhere('team_name', 'LIKE', "%{$s}%")
                    ->orWhere('participant_number', 'LIKE', "%{$s}%")
                    ->orWhereHas('members', function ($q2) use ($s) {
                        $q2->where('full_name', 'LIKE', "%{$s}%")
                            ->orWhere('nisn', 'LIKE', "%{$s}%")
                            ->orWhere('school_name', 'LIKE', "%{$s}%");
                    });
            });
        }

        // Hitung total keseluruhan, total PA dan PI secara akurat sesuai filter aktif (cabang lomba, status, sektor, pencarian)
        // Dihitung sebelum filter gender diterapkan agar badge tab filter PA dan PI tetap konsisten
        $baseGenderQuery = clone $query;
        $totalAll = (clone $baseGenderQuery)->count();
        $totalPa = (clone $baseGenderQuery)->where(function ($q) {
            $q->whereHas('members', fn ($m) => $m->where('gender', 'L'))
                ->orWhere('match_type', 'LIKE', '%Putra%')
                ->orWhere('match_type', 'LIKE', '%(PA)%');
        })->count();
        $totalPi = (clone $baseGenderQuery)->where(function ($q) {
            $q->whereHas('members', fn ($m) => $m->where('gender', 'P'))
                ->orWhere('match_type', 'LIKE', '%Putri%')
                ->orWhere('match_type', 'LIKE', '%(PI)%');
        })->count();

        // Hitung statistik terverifikasi, sudah diundi, dan status counts khusus untuk cabang lomba (dan gender) aktif
        $statsCompQuery = Registration::whereIn('competition_id', $competitionIds);
        if ($request->filled('competition_id') && $request->competition_id !== 'all') {
            $statsCompQuery->where('competition_id', $request->competition_id);
        }
        if ($request->filled('gender') && $request->gender !== 'all') {
            $statsCompQuery->where(function ($q) use ($request) {
                $q->whereHas('members', fn ($m) => $m->where('gender', $request->gender))
                    ->orWhere(function ($q2) use ($request) {
                        if ($request->gender === 'L') {
                            $q2->where('match_type', 'LIKE', '%Putra%')->orWhere('match_type', 'LIKE', '%(PA)%');
                        } else {
                            $q2->where('match_type', 'LIKE', '%Putri%')->orWhere('match_type', 'LIKE', '%(PI)%');
                        }
                    });
            });
        }

        $totalVerified = (clone $statsCompQuery)->where('status', 'verified')->count();
        $totalDrawn = (clone $statsCompQuery)->whereNotNull('draw_number')->count();

        $statusGroupCounts = (clone $statsCompQuery)
            ->selectRaw('status, count(*) as count')
            ->groupBy('status')
            ->pluck('count', 'status');

        $statusSummary = [
            'verified' => (int) ($statusGroupCounts->get('verified', 0)),
            'pending' => (int) ($statusGroupCounts->get('pending', 0)),
            'revision' => (int) ($statusGroupCounts->get('revision', 0)),
            'rejected' => (int) ($statusGroupCounts->get('rejected', 0)),
        ];

        // Filter gender (via first member or match_type fallback)
        if ($request->filled('gender') && $request->gender !== 'all') {
            $g = $request->gender;
            $sectorIsPa = str_ends_with($request->sector ?? '', '_pa');
            $sectorIsPi = str_ends_with($request->sector ?? '', '_pi');

            // Abaikan filter gender jika sektor sudah spesifik gender berlawanan (mencegah tabrakan 0 data)
            if (! ($sectorIsPa && $g === 'P') && ! ($sectorIsPi && $g === 'L')) {
                $query->where(function ($q) use ($g) {
                    $q->whereHas('members', fn ($m) => $m->where('gender', $g))
                        ->orWhere(function ($q2) use ($g) {
                            if ($g === 'L') {
                                $q2->where('match_type', 'LIKE', '%Putra%')->orWhere('match_type', 'LIKE', '%(PA)%');
                            } else {
                                $q2->where('match_type', 'LIKE', '%Putri%')->orWhere('match_type', 'LIKE', '%(PI)%');
                            }
                        });
                });
            }
        }

        // Dynamic Sorting
        $sortBy = $request->get('sort_by', 'created_at');
        $sortDir = strtolower($request->get('sort_dir', 'desc')) === 'asc' ? 'asc' : 'desc';

        switch ($sortBy) {
            case 'id':
            case 'no':
                $query->orderBy('registrations.id', $sortDir);
                break;
            case 'participant_number':
            case 'code':
                $query->orderByRaw('CASE WHEN participant_number IS NULL OR participant_number = "" THEN 1 ELSE 0 END, participant_number '.$sortDir)
                    ->orderBy('registrations.registration_code', $sortDir);
                break;
            case 'name':
                $query->orderByRaw('COALESCE(team_name, (SELECT full_name FROM registration_members WHERE registration_members.registration_id = registrations.id ORDER BY id ASC LIMIT 1), "") '.$sortDir);
                break;
            case 'category':
            case 'branch':
                $query->orderBy('registrations.competition_id', $sortDir)
                    ->orderBy('registrations.target_class', $sortDir)
                    ->orderBy('registrations.match_type', $sortDir);
                break;
            case 'school':
                $query->orderByRaw('COALESCE(institution_name, (SELECT school_name FROM registration_members WHERE registration_members.registration_id = registrations.id ORDER BY id ASC LIMIT 1), "") '.$sortDir);
                break;
            case 'draw_number':
                $query->orderByRaw('CASE WHEN draw_number IS NULL THEN 1 ELSE 0 END, draw_number '.$sortDir);
                break;
            case 'documents':
            case 'files':
                $query->orderByRaw('CASE WHEN (document_file IS NOT NULL AND document_file != "") OR (payment_proof IS NOT NULL AND payment_proof != "") THEN 0 ELSE 1 END '.$sortDir)
                    ->orderBy('registrations.id', 'desc');
                break;
            case 'status':
                $query->orderBy('registrations.status', $sortDir);
                break;
            case 'created_at':
            default:
                $query->orderBy('registrations.created_at', $sortDir)->orderBy('registrations.id', $sortDir);
                break;
        }

        $perPage = min((int) $request->get('per_page', 15), 100);
        $paginated = $query->paginate($perPage);

        $compIds = $paginated->getCollection()->pluck('competition_id')->unique()->filter()->values()->all();
        $allCompRegs = Registration::whereIn('competition_id', $compIds)
            ->with('members:id,registration_id,school_name,gender,full_name')
            ->get(['id', 'competition_id', 'target_class', 'match_type', 'institution_name', 'sub_category', 'team_name', 'registration_code', 'participant_number']);

        $poolSchoolMembers = [];

        foreach ($allCompRegs as $cr) {
            $cId = $cr->competition_id;
            $s1 = trim(mb_strtolower($cr->display_school ?: $cr->institution_name ?: ''));
            if ($s1 === '' || $s1 === '-') {
                continue;
            }

            // Pool Key memisahkan kelas (Kat A/B/C/Ganda) dan Sektor (PA vs PI vs MIX)
            $poolKey = $cr->getPoolClassificationKey();
            $poolLookup = "{$cId}_{$poolKey}_{$s1}";

            $pName = $cr->pure_name;
            $poolSchoolMembers[$poolLookup][] = [
                'id' => $cr->id,
                'name' => $pName,
                'code' => $cr->registration_code,
                'pool_key' => $poolKey,
            ];
        }

        $items = $paginated->getCollection()->map(function ($r) use ($poolSchoolMembers) {
            $firstMember = $r->members->first();
            $schoolNorm = trim(mb_strtolower($r->display_school ?: $r->institution_name ?: ''));
            $poolLookup = "{$r->competition_id}_{$r->getPoolClassificationKey()}_{$schoolNorm}";

            // Satu Delegasi HANYA untuk peserta dari sekolah sama dalam pool yang sama (kelas sama & gender sama)
            $poolTeammates = collect($poolSchoolMembers[$poolLookup] ?? [])->where('id', '!=', $r->id)->values()->all();

            $inPoolCount = count($poolTeammates) > 0 ? (count($poolTeammates) + 1) : 0;
            $hasSamePoolTeammates = count($poolTeammates) > 0;
            $hasTeammates = $hasSamePoolTeammates;

            $poolTeammateNames = array_column($poolTeammates, 'name');
            $teammateDetails = $hasSamePoolTeammates
                ? ('Rekan 1 Kategori & Sektor: '.implode(', ', $poolTeammateNames).' (Proteksi Undian BWF Aktif)')
                : '';

            return [
                'id' => $r->id,
                'comp_id' => (string) $r->competition_id,
                'comp_name' => $r->competition?->name ?? '',
                'comp_code' => $r->competition?->code ?? '',
                'participant_number' => $r->participant_number ?: '-',
                'registration_code' => $r->registration_code,
                'display_name' => $r->display_name,
                'team_name' => $r->team_name,
                'display_school' => $r->display_school,
                'has_teammates' => $hasTeammates,
                'is_same_pool_teammate' => $hasSamePoolTeammates,
                'same_school_count' => $inPoolCount,
                'same_pool_count' => $inPoolCount,
                'same_comp_count' => $inPoolCount,
                'teammate_names' => implode(', ', $poolTeammateNames),
                'teammate_details' => $teammateDetails,
                'official_name' => $r->official_name,
                'document_file' => $r->document_file,
                'has_payment_proof' => (bool) ($r->payment_proof || ($r->invoice && $r->invoice->payment_proof)),
                'draw_number' => $r->draw_number,
                'sub_category' => $r->sub_category,
                'target_class' => $r->target_class,
                'chosen_song' => $r->chosen_song,
                'gender' => $r->primary_gender,
                'status' => $r->status,
                'is_ganda' => $r->isGanda(),
                'is_kat_a' => $r->isKatA(),
                'is_kat_b' => $r->isKatB(),
                'is_kat_c' => $r->isKatC(),
                'first_member_nisn' => $firstMember?->nisn ?: '-',
                'members' => $r->members->map(fn ($m) => [
                    'full_name' => $m->full_name,
                    'gender' => $m->gender,
                    'nisn' => $m->nisn,
                ])->values(),
                'search' => strtolower(
                    $r->display_name.' '.$r->registration_code.' '.
                    ($r->participant_number ?? '').' '.$r->display_school.' '.
                    $r->institution_name.' '.($firstMember?->nisn ?? '').' '.
                    $r->members->pluck('school_name')->filter()->implode(' ')
                ),
            ];
        });

        return response()->json([
            'data' => $items,
            'current_page' => $paginated->currentPage(),
            'last_page' => $paginated->lastPage(),
            'per_page' => $paginated->perPage(),
            'total' => $paginated->total(),
            'total_all' => $totalAll,
            'total_pa' => $totalPa,
            'total_pi' => $totalPi,
            'total_verified' => $totalVerified,
            'total_pending' => $statusSummary['pending'],
            'total_revision' => $statusSummary['revision'],
            'total_rejected' => $statusSummary['rejected'],
            'total_drawn' => $totalDrawn,
            'status_summary' => $statusSummary,
            'from' => $paginated->firstItem(),
            'to' => $paginated->lastItem(),
        ]);
    }

    /**
     * API: Full detail satu pendaftaran untuk modal verifikasi / edit / cetak
     * GET /pic/api/participants/{id}
     */
    public function apiParticipantDetail($id)
    {
        $user = Auth::user();
        if (! $user) {
            return response()->json(['message' => 'Sesi login telah berakhir. Silakan muat ulang halaman.'], 401);
        }

        $reg = Registration::with([
            'competition.category',
            'members',
            'user:id,name,phone,institution_name',
            'invoice:id,invoice_number,status,payment_proof,final_amount',
        ])->find($id);

        if (! $reg) {
            return response()->json(['message' => 'Data pendaftaran dengan ID #'.$id.' tidak ditemukan.'], 404);
        }

        return response()->json($reg);
    }

    public function printParticipantsPdf(Request $request)
    {
        $user = Auth::user();
        $competitionId = $request->query('competition_id', 'all');
        $status = $request->query('status', 'all');
        $genderFilter = $request->query('gender', 'all');
        $categoryClassFilter = $request->query('category_class', 'all');

        $managedCompIds = self::getManagedCompetitionIds($user);
        $query = Registration::with(['competition.category', 'competition.pic', 'members', 'user'])
            ->whereIn('competition_id', $managedCompIds)
            ->when($competitionId !== 'all', function ($q) use ($competitionId) {
                $q->where('competition_id', $competitionId);
            })
            ->when($status !== 'all', function ($q) use ($status) {
                $q->where('status', $status);
            })
            ->when($genderFilter !== 'all', function ($q) use ($genderFilter) {
                $q->whereHas('members', function ($mq) use ($genderFilter) {
                    $mq->where('gender', $genderFilter);
                });
            });

        $registrations = $query->get();

        // Helper closure to add paginated sector pages
        $addPaginatedSector = function (&$pages, $comp, $subGroupTitle, $sectorTitle, $genderBadgeClass, $regs, $picName, $picPosition) {
            $total = $regs->count();

            // If 16 or fewer, it fits on 1 single page with signatures
            if ($total <= 16) {
                $pages[] = [
                    'competition' => $comp,
                    'competition_name' => $comp->name,
                    'sub_group_title' => $subGroupTitle,
                    'sector_title' => $sectorTitle,
                    'gender_badge_class' => $genderBadgeClass,
                    'registrations' => $regs,
                    'start_number' => 1,
                    'has_signatures' => true,
                    'pic_name' => $picName,
                    'pic_position' => $picPosition,
                ];

                return;
            }

            // Detect if this dataset contains multi-member (ganda/team) rows which take double height
            $isMultiMember = $regs->contains(fn ($r) => $r->members->count() > 1);
            $maxFinalWithSignatures = $isMultiMember ? 9 : 14;
            $maxIntermediate = $isMultiMember ? 12 : 20;

            $remaining = $regs;
            $startNum = 1;
            $chunks = [];

            while ($remaining->count() > $maxFinalWithSignatures) {
                // If remaining <= (2 * maxFinalWithSignatures), split evenly so both pages are balanced
                $take = ($remaining->count() <= ($maxFinalWithSignatures * 2))
                    ? (int) ceil($remaining->count() / 2)
                    : $maxIntermediate;
                $chunks[] = [
                    'items' => $remaining->slice(0, $take)->values(),
                    'has_signatures' => false,
                    'start_number' => $startNum,
                ];
                $startNum += $take;
                $remaining = $remaining->slice($take)->values();
            }

            // Final chunk with signatures
            $chunks[] = [
                'items' => $remaining,
                'has_signatures' => true,
                'start_number' => $startNum,
            ];

            $totalChunks = count($chunks);
            foreach ($chunks as $cIdx => $chunk) {
                $suffix = ($totalChunks > 1) ? ' (Hal. '.($cIdx + 1).'/'.$totalChunks.')' : '';
                $pages[] = [
                    'competition' => $comp,
                    'competition_name' => $comp->name,
                    'sub_group_title' => $subGroupTitle,
                    'sector_title' => $sectorTitle.$suffix,
                    'gender_badge_class' => $genderBadgeClass,
                    'registrations' => $chunk['items'],
                    'start_number' => $chunk['start_number'],
                    'has_signatures' => $chunk['has_signatures'],
                    'pic_name' => $picName,
                    'pic_position' => $picPosition,
                ];
            }
        };

        // Group into printable separate pages
        $pages = [];
        $competitions = $registrations->groupBy('competition_id');

        foreach ($competitions as $compId => $compRegs) {
            $comp = $compRegs->first()->competition;
            $picName = (Auth::check() && Auth::user()->isPic()) ? Auth::user()->name : ($comp->pic->name ?? Auth::user()->name ?? 'Panitia Pelaksana');
            $picPosition = ! empty($comp->pic?->position) ? $comp->pic->position : 'Panitia Pelaksana';
            $isBuluTangkis = ($comp->code === 'BLT' || stripos($comp->name, 'bulu tangkis') !== false || stripos($comp->name, 'badminton') !== false);
            $isTenisMeja = ($comp->code === 'TMJ' || stripos($comp->name, 'tenis meja') !== false || stripos($comp->name, 'pingpong') !== false);
            $isRobotik = method_exists($comp, 'isRobotik') ? $comp->isRobotik() : ($comp->code === 'ROB' || stripos($comp->name, 'robot') !== false);

            if ($isBuluTangkis) {
                // 1. Tunggal Categories (Kat A, Kat B, Kat C)
                $bltCategories = [
                    'kat_a' => 'Kategori A (Kelas 1–2 SD/MI)',
                    'kat_b' => 'Kategori B (Kelas 3–4 SD/MI)',
                    'kat_c' => 'Kategori C (Kelas 5–6 SD/MI)',
                ];

                foreach ($bltCategories as $catKey => $catLabel) {
                    if ($categoryClassFilter !== 'all' && $categoryClassFilter !== $catKey) {
                        continue;
                    }

                    $catRegs = $compRegs->filter(function ($r) use ($catKey) {
                        if ($r->isGanda()) {
                            return false;
                        }
                        if ($catKey === 'kat_a') {
                            return $r->isKatA();
                        }
                        if ($catKey === 'kat_b') {
                            return $r->isKatB();
                        }
                        if ($catKey === 'kat_c') {
                            return $r->isKatC();
                        }

                        return false;
                    });

                    if ($catRegs->isNotEmpty()) {
                        $paRegs = $catRegs->filter(fn ($r) => $r->primary_gender === 'L')->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();
                        $piRegs = $catRegs->filter(fn ($r) => $r->primary_gender === 'P')->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();

                        if ($paRegs->isNotEmpty() && ($genderFilter === 'all' || $genderFilter === 'L')) {
                            $addPaginatedSector($pages, $comp, '👦 KELOMPOK PUTRA (PA)', $catLabel.' - TUNGGAL PUTRA', 'bg-blue-100 text-blue-900', $paRegs, $picName, $picPosition);
                        }
                        if ($piRegs->isNotEmpty() && ($genderFilter === 'all' || $genderFilter === 'P')) {
                            $addPaginatedSector($pages, $comp, '👧 KELOMPOK PUTRI (PI)', $catLabel.' - TUNGGAL PUTRI', 'bg-rose-100 text-rose-900', $piRegs, $picName, $picPosition);
                        }
                    }
                }

                // 2. Ganda Categories (Direct Ganda Putra & Ganda Putri)
                if ($categoryClassFilter === 'all' || $categoryClassFilter === 'ganda') {
                    $gandaAllRegs = $compRegs->filter(function ($r) {
                        $targetStr = strtolower(($r->target_class ?? '').' '.($r->sub_category ?? '').' '.($r->match_type ?? ''));

                        return stripos($targetStr, 'ganda') !== false || $r->members->count() > 1;
                    });

                    if ($gandaAllRegs->isNotEmpty()) {
                        $gandaPa = $gandaAllRegs->filter(fn ($r) => $r->primary_gender === 'L' || stripos($r->match_type, 'Putra') !== false || stripos($r->match_type, 'PA') !== false)->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();
                        $gandaPi = $gandaAllRegs->filter(fn ($r) => $r->primary_gender === 'P' || stripos($r->match_type, 'Putri') !== false || stripos($r->match_type, 'PI') !== false)->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();

                        if ($gandaPa->isNotEmpty() && ($genderFilter === 'all' || $genderFilter === 'L')) {
                            $addPaginatedSector($pages, $comp, '👥 KELOMPOK GANDA PUTRA (PA)', 'GANDA PUTRA (PA) - SEMUA KELAS', 'bg-blue-100 text-blue-900', $gandaPa, $picName, $picPosition);
                        }
                        if ($gandaPi->isNotEmpty() && ($genderFilter === 'all' || $genderFilter === 'P')) {
                            $addPaginatedSector($pages, $comp, '👥 KELOMPOK GANDA PUTRI (PI)', 'GANDA PUTRI (PI) - SEMUA KELAS', 'bg-rose-100 text-rose-900', $gandaPi, $picName, $picPosition);
                        }
                    }
                }
            } elseif ($isTenisMeja) {
                // Tenis Meja: Kategori A (Kelas 1–3 SD/MI) dan Kategori B (Kelas 4–6 SD/MI)
                $tmjCategories = [
                    'kat_a' => 'Kategori A (Kelas 1–3 SD/MI)',
                    'kat_b' => 'Kategori B (Kelas 4–6 SD/MI)',
                ];

                foreach ($tmjCategories as $catKey => $catLabel) {
                    if ($categoryClassFilter !== 'all' && $categoryClassFilter !== $catKey) {
                        continue;
                    }

                    $catRegs = $compRegs->filter(function ($r) use ($catKey) {
                        if ($catKey === 'kat_a') {
                            return $r->isKatA();
                        }
                        if ($catKey === 'kat_b') {
                            return $r->isKatB();
                        }

                        return false;
                    });

                    if ($catRegs->isNotEmpty()) {
                        $paRegs = $catRegs->filter(fn ($r) => $r->primary_gender === 'L')->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();
                        $piRegs = $catRegs->filter(fn ($r) => $r->primary_gender === 'P')->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();

                        if ($paRegs->isNotEmpty() && ($genderFilter === 'all' || $genderFilter === 'L')) {
                            $addPaginatedSector($pages, $comp, '👦 KELOMPOK PUTRA (PA)', $catLabel.' - TUNGGAL PUTRA', 'bg-blue-100 text-blue-900', $paRegs, $picName, $picPosition);
                        }
                        if ($piRegs->isNotEmpty() && ($genderFilter === 'all' || $genderFilter === 'P')) {
                            $addPaginatedSector($pages, $comp, '👧 KELOMPOK PUTRI (PI)', $catLabel.' - TUNGGAL PUTRI', 'bg-rose-100 text-rose-900', $piRegs, $picName, $picPosition);
                        }
                    }
                }
            } elseif ($isRobotik) {
                $robCategories = [
                    'sumo' => 'Robotik Sumo',
                    'soccer' => 'Robotik Soccer',
                    'kreatif' => 'Robotik Kreatif',
                ];

                foreach ($robCategories as $catKey => $catLabel) {
                    if ($categoryClassFilter !== 'all' && $categoryClassFilter !== $catKey && $categoryClassFilter !== 'rob_'.$catKey) {
                        continue;
                    }

                    $catRegs = $compRegs->filter(function ($r) use ($catKey) {
                        return stripos($r->match_type ?? '', $catKey) !== false
                            || stripos($r->sub_category ?? '', $catKey) !== false
                            || stripos($r->target_class ?? '', $catKey) !== false;
                    })->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();

                    if ($catRegs->isNotEmpty()) {
                        $addPaginatedSector($pages, $comp, '🤖 '.strtoupper($catLabel), $catLabel.' - SEMUA PESERTA', 'bg-purple-100 text-purple-900', $catRegs, $picName, $picPosition);
                    }
                }
            } else {
                // General Competition: Separate Page 1 (PA) and Page 2 (PI)
                $paRegs = $compRegs->filter(fn ($r) => $r->primary_gender === 'L')->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();
                $piRegs = $compRegs->filter(fn ($r) => $r->primary_gender === 'P')->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();
                $otherRegs = $compRegs->filter(fn ($r) => ! in_array($r->primary_gender, ['L', 'P']))->sortBy(fn ($r) => $r->draw_number ?: 9999)->values();

                if (($paRegs->isNotEmpty() || ($piRegs->isEmpty() && $otherRegs->isEmpty())) && ($genderFilter === 'all' || $genderFilter === 'L')) {
                    $addPaginatedSector($pages, $comp, '👦 KELOMPOK PUTRA (PA)', $comp->category->name ?? 'Tingkat SD/MI', 'bg-blue-100 text-blue-900', $paRegs, $picName, $picPosition);
                }
                if ($piRegs->isNotEmpty() && ($genderFilter === 'all' || $genderFilter === 'P')) {
                    $addPaginatedSector($pages, $comp, '👧 KELOMPOK PUTRI (PI)', $comp->category->name ?? 'Tingkat SD/MI', 'bg-rose-100 text-rose-900', $piRegs, $picName, $picPosition);
                }
                if ($otherRegs->isNotEmpty() && $genderFilter === 'all') {
                    $addPaginatedSector($pages, $comp, '👥 KELOMPOK BEREGU / CAMPURAN', $comp->category->name ?? 'Tingkat SD/MI', 'bg-purple-100 text-purple-900', $otherRegs, $picName, $picPosition);
                }
            }
        }

        return view('pic.print-participants-pdf', compact('pages'));
    }

    public function exportParticipantsExcel(Request $request)
    {
        $user = Auth::user();
        $competitionId = $request->query('competition_id', 'all');
        $status = $request->query('status', 'all');
        $genderFilter = $request->query('gender', 'all');
        $categoryClassFilter = $request->query('category_class', 'all');

        $managedCompIds = self::getManagedCompetitionIds($user);
        $query = Registration::with(['competition.category', 'members', 'user'])
            ->whereIn('competition_id', $managedCompIds)
            ->when($competitionId !== 'all', function ($q) use ($competitionId) {
                $q->where('competition_id', $competitionId);
            })
            ->when($status !== 'all', function ($q) use ($status) {
                $q->where('status', $status);
            })
            ->when($genderFilter !== 'all', function ($q) use ($genderFilter) {
                $q->whereHas('members', function ($mq) use ($genderFilter) {
                    $mq->where('gender', $genderFilter);
                });
            });

        $registrations = $query->get();

        // Apply category filter if specified
        if ($categoryClassFilter !== 'all') {
            $registrations = $registrations->filter(function ($r) use ($categoryClassFilter) {
                $compCode = $r->competition?->code ?? '';
                if ($compCode === 'TMJ') {
                    if ($categoryClassFilter === 'kat_a') {
                        return $r->isKatA();
                    }
                    if ($categoryClassFilter === 'kat_b') {
                        return $r->isKatB();
                    }
                } elseif ($compCode === 'BLT') {
                    if ($categoryClassFilter === 'kat_a') {
                        return ! $r->isGanda() && $r->isKatA();
                    }
                    if ($categoryClassFilter === 'kat_b') {
                        return ! $r->isKatB();
                    }
                    if ($categoryClassFilter === 'kat_c') {
                        return ! $r->isKatC();
                    }
                    if ($categoryClassFilter === 'ganda') {
                        return $r->isGanda();
                    }
                }

                return true;
            });
        }

        // Helper to get category tier weight for sorting
        $getCategoryWeight = function ($reg) {
            $compCode = $reg->competition?->code ?? '';
            if ($compCode === 'TMJ') {
                if ($reg->isKatA()) {
                    return 1;
                }
                if ($reg->isKatB()) {
                    return 2;
                }

                return 3;
            } elseif ($compCode === 'BLT') {
                if (! $reg->isGanda()) {
                    if ($reg->isKatA()) {
                        return 1;
                    }
                    if ($reg->isKatB()) {
                        return 2;
                    }
                    if ($reg->isKatC()) {
                        return 3;
                    }
                }
                if ($reg->isGanda()) {
                    return 4;
                }

                return 5;
            }

            return 1;
        };

        // Sort into 1 single sheet: by Competition -> by Category Tier -> by Gender (PA then PI) -> by Draw/Participant No
        $sorted = $registrations->sort(function ($a, $b) use ($getCategoryWeight) {
            if ($a->competition_id !== $b->competition_id) {
                return strcmp($a->competition->name ?? '', $b->competition->name ?? '');
            }

            // Sort by Category tier (Kat A -> Kat B -> Kat C -> Ganda)
            $catWeightA = $getCategoryWeight($a);
            $catWeightB = $getCategoryWeight($b);
            if ($catWeightA !== $catWeightB) {
                return $catWeightA <=> $catWeightB;
            }

            // Sort by Gender (PA -> PI -> Other)
            $genderOrder = ['L' => 1, 'P' => 2, 'M' => 3];
            $gA = $genderOrder[$a->primary_gender] ?? 4;
            $gB = $genderOrder[$b->primary_gender] ?? 4;
            if ($gA !== $gB) {
                return $gA <=> $gB;
            }

            // Sort by draw number if exists, else participant number
            $drawA = (int) ($a->draw_number ?: 9999);
            $drawB = (int) ($b->draw_number ?: 9999);
            if ($drawA !== $drawB) {
                return $drawA <=> $drawB;
            }

            return strcmp($a->participant_number ?? '', $b->participant_number ?? '');
        });

        // Determine whether to show "No. Undian" column in Excel:
        // Hide if selected competition is BLT or TMJ, or if all exported registrations belong to BLT/TMJ
        $hideDrawCol = false;
        if ($competitionId !== 'all') {
            $firstComp = $sorted->first()?->competition;
            if ($firstComp && (in_array($firstComp->code, ['BLT', 'TMJ']) || stripos($firstComp->name, 'tenis') !== false || stripos($firstComp->name, 'tangkis') !== false || stripos($firstComp->name, 'badminton') !== false)) {
                $hideDrawCol = true;
            }
        } elseif ($sorted->isNotEmpty() && $sorted->every(function ($r) {
            $code = $r->competition?->code ?? '';
            $name = $r->competition?->name ?? '';

            return in_array($code, ['BLT', 'TMJ']) || stripos($name, 'tenis') !== false || stripos($name, 'tangkis') !== false || stripos($name, 'badminton') !== false;
        })) {
            $hideDrawCol = true;
        }

        $colspan = $hideDrawCol ? 12 : 13;
        $filename = 'DATA_PESERTA_TALENTA_2026_'.date('Ymd_His').'.xls';

        return response()->streamDownload(function () use ($sorted, $hideDrawCol, $colspan) {
            echo '<!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: Calibri, sans-serif; }
                    th { background-color: #064E3B; color: #FFFFFF; font-weight: bold; border: 1px solid #000000; text-align: center; }
                    td { border: 1px solid #CCCCCC; vertical-align: middle; }
                    .center { text-align: center; }
                    .bold { font-weight: bold; }
                    .pa { background-color: #EFF6FF; }
                    .pi { background-color: #FFF1F2; }
                </style>
            </head>
            <body>
                <table border="1">
                    <tr>
                        <th colspan="'.$colspan.'" style="font-size: 16pt; background-color: #047857; text-align: center; height: 35px;">
                            DATA NOMINATIF PESERTA RESMI TALENTA 2026 - MTsN 1 BLITAR
                        </th>
                    </tr>
                    <tr>
                        <th colspan="'.$colspan.'" style="font-size: 10pt; background-color: #D1FAE5; color: #065F46; text-align: center;">
                            Diurutkan Berdasarkan Cabang Lomba, Kategori/Kelas & Kelompok Gender (Putra / Putri) dalam 1 Sheet
                        </th>
                    </tr>
                    <tr>
                        <th>No</th>
                        <th>Kode Registrasi</th>
                        <th>No. Peserta</th>
                        '.(! $hideDrawCol ? '<th>No. Undian</th>' : '').'
                        <th>Nama Peserta / Atlet</th>
                        <th>NISN</th>
                        <th>Gender (PA/PI)</th>
                        <th>Cabang Lomba</th>
                        <th>Kategori / Sektor</th>
                        <th>Asal Sekolah / Madrasah</th>
                        <th>Nama Official</th>
                        <th>No. HP Official</th>
                        <th>Status Keabsahan</th>
                    </tr>';

            $no = 1;
            foreach ($sorted as $reg) {
                $firstMember = $reg->members->first();
                $isGanda = $reg->members->count() > 1 || $reg->isGanda();
                $gender = $reg->primary_gender;
                $genderClass = ($gender === 'L') ? 'pa' : (($gender === 'P') ? 'pi' : '');
                $genderLabel = ($gender === 'L') ? 'Putra (PA)' : (($gender === 'P') ? 'Putri (PI)' : 'Ganda / Campuran');

                $compCode = $reg->competition?->code ?? '';
                $sectorLabel = '';
                if ($compCode === 'TMJ') {
                    $catStr = $reg->isKatA() ? 'Kategori A (Kelas 1–3)' : ($reg->isKatB() ? 'Kategori B (Kelas 4–6)' : ($reg->target_class ?: 'Semua Kelas'));
                    $genStr = $gender === 'L' ? 'Tunggal Putra (PA)' : ($gender === 'P' ? 'Tunggal Putri (PI)' : 'Tunggal');
                    $sectorLabel = $catStr.' - '.$genStr;
                } elseif ($compCode === 'BLT') {
                    if ($isGanda) {
                        $sectorLabel = ($gender === 'L' ? 'Ganda Putra (PA)' : ($gender === 'P' ? 'Ganda Putri (PI)' : 'Ganda')).' - Semua Kelas';
                    } elseif ($reg->isKatA()) {
                        $sectorLabel = 'Kategori A (Kelas 1–2) - '.($gender === 'L' ? 'Tunggal Putra (PA)' : 'Tunggal Putri (PI)');
                    } elseif ($reg->isKatB()) {
                        $sectorLabel = 'Kategori B (Kelas 3–4) - '.($gender === 'L' ? 'Tunggal Putra (PA)' : 'Tunggal Putri (PI)');
                    } elseif ($reg->isKatC()) {
                        $sectorLabel = 'Kategori C (Kelas 5–6) - '.($gender === 'L' ? 'Tunggal Putra (PA)' : 'Tunggal Putri (PI)');
                    } else {
                        $sectorLabel = ($reg->target_class ?: 'Semua Kelas').' - '.($gender === 'L' ? 'Putra (PA)' : 'Putri (PI)');
                    }
                } else {
                    $sectorLabel = trim(($reg->target_class ?: '').' '.($reg->sub_category ?: ''));
                    if (empty($sectorLabel)) {
                        $sectorLabel = $reg->competition->category->name ?? 'Tingkat SD/MI';
                    }
                }

                $participantPureName = $reg->pure_name;
                $schoolName = $reg->display_school ?: ($reg->institution_name ?: '-');

                echo '<tr class="'.$genderClass.'">
                    <td class="center">'.$no++.'</td>
                    <td class="center">'.htmlspecialchars($reg->registration_code).'</td>
                    <td class="center bold">'.htmlspecialchars($reg->participant_number ?: '-').'</td>
                    '.(! $hideDrawCol ? '<td class="center bold">'.htmlspecialchars($reg->draw_number ? '#'.$reg->draw_number : '-').'</td>' : '').'
                    <td class="bold">'.htmlspecialchars($participantPureName).'</td>
                    <td class="center">'.htmlspecialchars($firstMember?->nisn ?: '-').'</td>
                    <td class="center bold">'.htmlspecialchars($genderLabel).'</td>
                    <td>'.htmlspecialchars($reg->competition->name ?? '-').'</td>
                    <td>'.htmlspecialchars($sectorLabel).'</td>
                    <td>'.htmlspecialchars($schoolName).'</td>
                    <td>'.htmlspecialchars($reg->official_name ?: '-').'</td>
                    <td class="center">'.htmlspecialchars($reg->official_phone ?: '-').'</td>
                    <td class="center bold">'.ucfirst($reg->status).'</td>
                </tr>';
            }

            echo '</table></body></html>';
        }, $filename, [
            'Content-Type' => 'application/vnd.ms-excel; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="'.$filename.'"',
        ]);
    }

    public function participants(Request $request, $competition_id)
    {
        $user = Auth::user();
        $competition = Competition::with('category')->findOrFail($competition_id);

        $this->authorizeCompetitionManagement($user, $competition->id);

        $statusFilter = $request->input('status', 'all');

        $registrations = Registration::with(['members', 'user', 'scores', 'invoice', 'competition.category'])
            ->where('competition_id', $competition->id)
            ->when($statusFilter !== 'all', function ($q) use ($statusFilter) {
                $q->where('status', $statusFilter);
            })
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $allRegs = Registration::where('competition_id', $competition->id)
            ->with('members:id,registration_id,school_name,gender,full_name')
            ->get(['id', 'competition_id', 'target_class', 'match_type', 'institution_name', 'sub_category', 'team_name', 'registration_code']);
        $schoolCounts = [];
        $poolSchoolMembers = [];
        $compSchoolMembers = [];

        foreach ($allRegs as $ar) {
            $s1 = trim(mb_strtolower($ar->display_school ?: $ar->institution_name ?: ''));
            if ($s1 !== '' && $s1 !== '-') {
                $poolKey = $ar->getPoolClassificationKey();
                $poolLookup = "{$poolKey}_{$s1}";
                $pName = $ar->pure_name;
                $poolSchoolMembers[$poolLookup][] = [
                    'id' => $ar->id,
                    'name' => $pName,
                ];
            }
        }

        return view('pic.participants', compact('competition', 'registrations', 'statusFilter', 'poolSchoolMembers'));
    }

    public function verifyParticipant(Request $request, $registration_id)
    {
        $registration = Registration::with(['competition', 'invoice.registrations'])->findOrFail($registration_id);
        $user = Auth::user();
        $this->authorizeCompetitionManagement($user, $registration->competition_id);

        $validated = $request->validate([
            'status' => ['required', 'in:verified,rejected,revision'],
            'verification_notes' => ['nullable', 'string'],
        ]);

        $registration->status = $validated['status'];
        $registration->verification_notes = $validated['verification_notes'];
        $registration->verified_by = $user->id;
        $registration->verified_at = now();

        // If verified, generate official participant number if not exists
        if ($validated['status'] === 'verified' && empty($registration->participant_number)) {
            $registration->participant_number = $registration->generateParticipantNumber();
        }

        $registration->save();

        ActivityLog::record(
            $validated['status'] === 'verified' ? 'VERIFY_SUCCESS' : 'VERIFY_REJECT',
            ($validated['status'] === 'verified' ? 'Memverifikasi sah' : 'Menolak')." peserta '{$registration->display_name}' ({$registration->registration_code}) pada cabang {$registration->competition->name}".($validated['verification_notes'] ? ". Catatan: {$validated['verification_notes']}" : ''),
            $user,
            $validated['status'] === 'verified' ? 'success' : 'warning'
        );

        // Auto-sync invoice status if part of collective registration
        if ($registration->invoice_id && $registration->invoice) {
            $invoice = $registration->invoice;
            $allRegs = $invoice->registrations;

            if ($allRegs->every(fn ($r) => $r->status === 'verified')) {
                $invoice->update([
                    'status' => 'verified',
                    'verified_at' => now(),
                    'verified_by' => $user->id,
                ]);
            } elseif ($validated['status'] === 'rejected' && $invoice->status === 'pending') {
                $invoice->update([
                    'status' => 'rejected',
                    'verified_at' => now(),
                    'verified_by' => $user->id,
                    'rejection_reason' => $validated['verification_notes'] ?? 'Ditolak saat verifikasi berkas/pembayaran.',
                ]);
            }
        }

        $waSent = false;
        $targetPhones = [];

        // Trigger Auto WhatsApp Notification: Status Verifikasi (Sah, Revisi, atau Tolak)
        try {
            $registration->loadMissing(['members', 'user', 'competition']);
            $memberNisns = $registration->members->pluck('nisn')->filter()->unique();
            $nisn = $memberNisns->isNotEmpty() ? $memberNisns->implode(' / ') : ($registration->user?->nisn ?? '-');
            $targetPhones = $registration->recipient_phones;

            if (empty($targetPhones)) {
                if (! empty($registration->official_phone)) {
                    $targetPhones[] = $registration->official_phone;
                } elseif (! empty($registration->user?->phone)) {
                    $targetPhones[] = $registration->user->phone;
                }
            }

            if (! empty($targetPhones)) {
                if ($validated['status'] === 'verified') {
                    $waSent = WablasNotificationService::sendAutoNotification('registration_verified', [
                        'phone' => $targetPhones,
                        'nama_peserta' => $registration->pure_name,
                        'nisn' => $nisn,
                        'nama_sekolah' => $registration->institution_name,
                        'cabang_lomba' => $registration->competition->name,
                        'no_peserta' => $registration->participant_number ?: $registration->registration_code,
                        'kode_pendaftaran' => $registration->registration_code,
                        'link_scoreboard' => url('/'),
                        'link_login' => route('login'),
                    ]);
                } elseif ($validated['status'] === 'revision') {
                    $waSent = WablasNotificationService::sendAutoNotification('registration_revision', [
                        'phone' => $targetPhones,
                        'nama_peserta' => $registration->pure_name,
                        'nisn' => $nisn,
                        'nama_sekolah' => $registration->institution_name,
                        'cabang_lomba' => $registration->competition->name,
                        'kode_pendaftaran' => $registration->registration_code,
                        'catatan_verifikasi' => $validated['verification_notes'] ?: 'Mohon periksa kembali berkas persyaratan lomba Anda.',
                        'link_login' => route('peserta.registration.detail', $registration->id),
                    ]);
                } elseif ($validated['status'] === 'rejected') {
                    $waSent = WablasNotificationService::sendAutoNotification('registration_rejected', [
                        'phone' => $targetPhones,
                        'nama_peserta' => $registration->pure_name,
                        'nisn' => $nisn,
                        'nama_sekolah' => $registration->institution_name,
                        'cabang_lomba' => $registration->competition->name,
                        'kode_pendaftaran' => $registration->registration_code,
                        'catatan_verifikasi' => $validated['verification_notes'] ?: 'Berkas pendaftaran tidak memenuhi kriteria lomba.',
                        'link_login' => route('login'),
                    ]);
                }
            }
        } catch (\Throwable $e) {
            // Non-blocking
            Log::error("Gagal mengirim WhatsApp status verifikasi ({$validated['status']}): ".$e->getMessage());
        }

        $phoneList = ! empty($targetPhones) ? implode(', ', $targetPhones) : 'tidak ada nomor';
        $msgFeedback = 'Status pendaftaran '.$registration->registration_code.' berhasil diubah menjadi: '.ucfirst($validated['status']).'.';
        if ($waSent) {
            $msgFeedback .= ' 📲 Notifikasi WhatsApp berhasil dikirimkan ke: '.$phoneList.'.';
        } else {
            $msgFeedback .= ' (Info: Notifikasi WA otomatis belum terkirim. Tujuan: '.$phoneList.').';
        }

        return back()->with('success', $msgFeedback);
    }

    public function updateParticipantData(Request $request, $registration_id)
    {
        $registration = Registration::with(['competition', 'members'])->findOrFail($registration_id);
        $user = Auth::user();

        $this->authorizeCompetitionManagement($user, $registration->competition_id);

        $validated = $request->validate([
            'institution_name' => ['required', 'string', 'max:255'],
            'official_name' => ['nullable', 'string', 'max:255'],
            'official_phone' => ['nullable', 'string', 'max:20'],
            'team_name' => ['nullable', 'string', 'max:255'],
            'target_class' => ['nullable', 'string', 'max:50'],
            'match_type' => ['nullable', 'string', 'max:50'],
            'participant_number' => ['nullable', 'string', 'max:50'],
            'draw_number' => ['nullable', 'integer'],
            'members' => ['required', 'array', 'min:1'],
            'members.*.id' => ['nullable', 'integer'],
            'members.*.full_name' => ['required', 'string', 'max:255'],
            'members.*.school_name' => ['nullable', 'string', 'max:255'],
            'members.*.nisn' => ['nullable', 'string', 'max:20'],
            'members.*.gender' => ['required', 'in:L,P'],
            'members.*.birth_place' => ['nullable', 'string', 'max:100'],
            'members.*.birth_date' => ['nullable', 'date'],
            'members.*.phone' => ['nullable', 'string', 'max:20'],
            'document_file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:5120'],
            'payment_proof' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:5120'],
        ]);

        $finalInstitutionName = trim($validated['institution_name']);

        // Synchronize school name for single participant or ganda
        if (count($validated['members']) === 1 && ! empty($validated['members'][0]['school_name'])) {
            $firstSchool = trim($validated['members'][0]['school_name']);
            // Prioritize the member's school name so that editing "Asal Sekolah Siswa" updates the institution
            $finalInstitutionName = $firstSchool;
        } elseif (count($validated['members']) > 1) {
            $memberSchools = array_unique(array_filter(array_map('trim', array_column($validated['members'], 'school_name'))));
            // If member schools are multiple and different, and institution_name wasn't custom-changed
            if (count($memberSchools) > 1 && $validated['institution_name'] === $registration->getOriginal('institution_name')) {
                $finalInstitutionName = implode(' / ', $memberSchools);
            }
        }

        $registration->institution_name = $finalInstitutionName;
        $registration->official_name = $validated['official_name'];
        $registration->official_phone = $validated['official_phone'];
        $registration->team_name = $validated['team_name'] ?? null;
        $registration->target_class = $validated['target_class'] ?? null;
        if (! empty($validated['match_type'])) {
            $registration->match_type = $validated['match_type'];
        }
        $registration->participant_number = $validated['participant_number'] ?? null;
        $registration->draw_number = ! empty($validated['draw_number']) ? $validated['draw_number'] : null;
        if ($request->has('chosen_song')) {
            $registration->chosen_song = $request->input('chosen_song') ?: null;
        }

        $compCode = $registration->competition?->code ?? (Competition::find($registration->competition_id)?->code ?? '');

        if ($compCode === 'BLT') {
            if ($registration->match_type && stripos($registration->match_type, 'ganda') !== false) {
                $registration->target_class = 'Ganda (Semua Kelas)';
                $registration->sub_category = $registration->match_type;
            } else {
                if (empty($registration->target_class) || stripos($registration->target_class, 'ganda') !== false) {
                    $registration->target_class = 'Kategori A (Kelas 1 - 2)';
                }
                if (! empty($registration->match_type)) {
                    $registration->sub_category = $registration->target_class.' - '.$registration->match_type;
                }
            }
        } elseif ($compCode === 'TMJ') {
            $registration->team_name = null;
            $rawTc = $validated['target_class'] ?? $registration->target_class ?? '';
            if (stripos($rawTc, '4-6') !== false || stripos($rawTc, '4 - 6') !== false || stripos($rawTc, 'Kat B') !== false || stripos($rawTc, 'Kategori B') !== false) {
                $registration->target_class = 'Kategori B (Kelas 4 - 6)';
            } else {
                $registration->target_class = 'Kategori A (Kelas 1 - 3)';
            }

            if (! empty($validated['match_type'])) {
                $registration->match_type = $validated['match_type'];
            }
            $registration->sub_category = $registration->target_class.' - '.($registration->match_type ?: 'Tunggal Putra (PA)');
        } elseif (in_array($compCode, ['MTQ', 'POP'])) {
            if (! empty($registration->match_type)) {
                $registration->sub_category = $registration->match_type;
            }
        } elseif ($compCode === 'ROB' || stripos($registration->competition?->name ?? '', 'robot') !== false) {
            $cat = $validated['match_type'] ?? ($validated['target_class'] ?? ($registration->match_type ?: 'Kreatif'));
            if (stripos($cat, 'Sumo') !== false) {
                $registration->match_type = 'Sumo';
                $registration->sub_category = 'Robotik Sumo';
            } elseif (stripos($cat, 'Soccer') !== false) {
                $registration->match_type = 'Soccer';
                $registration->sub_category = 'Robotik Soccer';
            } else {
                $registration->match_type = 'Kreatif';
                $registration->sub_category = 'Robotik Kreatif';
            }
            $registration->target_class = $registration->match_type;
        }

        if ($request->hasFile('document_file')) {
            $registration->document_file = $request->file('document_file')->store('documents', 'public');
            AdminSettingsController::ensurePublicStorageSync($registration->document_file);
        }
        if ($request->hasFile('payment_proof')) {
            $registration->payment_proof = ImageOptimizerService::storePaymentProof($request->file('payment_proof'), 'payments', 'pic_edit');
        }

        $registration->save();

        // Update member records
        foreach ($validated['members'] as $idx => $mData) {
            if (! empty($mData['id'])) {
                $member = RegistrationMember::where('registration_id', $registration->id)->find($mData['id']);
                if ($member) {
                    $mGender = $mData['gender'];
                    // Auto-sync gender if single/individual sector was selected
                    if ($registration->competition && in_array($registration->competition->code, ['TMJ', 'BLT', 'MTQ', 'POP'])) {
                        if ($registration->match_type && stripos($registration->match_type, 'ganda') === false) {
                            if (stripos($registration->match_type, 'Putri') !== false || stripos($registration->match_type, '(PI)') !== false) {
                                $mGender = 'P';
                            } elseif (stripos($registration->match_type, 'Putra') !== false || stripos($registration->match_type, '(PA)') !== false) {
                                $mGender = 'L';
                            }
                        }
                    }

                    $mSchool = ! empty($mData['school_name']) ? trim($mData['school_name']) : (count($validated['members']) === 1 ? $finalInstitutionName : null);
                    $member->update([
                        'full_name' => $mData['full_name'],
                        'school_name' => $mSchool,
                        'nisn' => $mData['nisn'] ?? null,
                        'gender' => $mGender,
                        'birth_place' => $mData['birth_place'] ?? null,
                        'birth_date' => $mData['birth_date'] ?? null,
                        'phone' => $mData['phone'] ?? null,
                    ]);
                }
            }
        }

        if ($registration->invoice_id) {
            $registration->invoice?->recalculateTotals();
        }

        return back()->with('success', 'Data pendaftaran '.$registration->display_name.' ('.$registration->registration_code.') berhasil diperbarui oleh Admin.');
    }

    public function unverifyParticipant($registration_id)
    {
        $registration = Registration::with(['competition', 'invoice.registrations'])->findOrFail($registration_id);
        $user = Auth::user();

        $this->authorizeCompetitionManagement($user, $registration->competition_id);

        $registration->status = 'pending';
        $registration->verified_at = null;
        $registration->verified_by = null;
        $registration->verification_notes = 'Verifikasi dibatalkan oleh Panitia/Admin. Data pendaftaran dibuka kembali untuk diedit.';
        $registration->save();

        if ($registration->invoice_id && $registration->invoice) {
            $registration->invoice->update([
                'status' => 'pending',
                'verified_at' => null,
                'verified_by' => null,
            ]);
        }

        ActivityLog::record(
            'UNVERIFY',
            "Membatalkan verifikasi pendaftaran '{$registration->display_name}' ({$registration->registration_code}) kembali ke Pending",
            $user,
            'warning'
        );

        return back()->with('success', 'Verifikasi pendaftaran '.$registration->registration_code.' telah dibatalkan. Status otomatis kembali menjadi Menunggu dan peserta dapat mengedit data di akunnya.');
    }

    public function deleteParticipant($registration_id)
    {
        $registration = Registration::with(['competition'])->findOrFail($registration_id);
        $user = Auth::user();

        $this->authorizeCompetitionManagement($user, $registration->competition_id);

        $code = $registration->registration_code;
        $name = $registration->display_name;

        $registration->scores()->delete();
        $registration->drawAllocation()->delete();
        $registration->members()->delete();
        $registration->delete();

        ActivityLog::record(
            'DELETE_PARTICIPANT',
            "Menghapus data pendaftaran peserta '{$name}' ({$code}) secara permanen",
            $user,
            'danger'
        );

        return back()->with('success', 'Data pendaftaran '.$name.' ('.$code.') berhasil dihapus secara permanen.');
    }

    /**
     * Store manual participant registration by Admin or PIC
     */
    public function storeParticipant(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'competition_id' => ['required', 'exists:competitions,id'],
            'full_name' => ['required', 'string', 'max:255'],
            'gender' => ['required', 'in:L,P'],
            'institution_name' => ['required', 'string', 'max:255'],
            'nisn' => ['nullable', 'string', 'max:20'],
            'phone' => ['nullable', 'string', 'max:20'],
            'match_type' => ['nullable', 'string', 'max:50'],
            'target_class' => ['nullable', 'string', 'max:50'],
            'status' => ['required', 'in:pending,verified'],
            'payment_method' => ['required', 'in:tunai,transfer'],
            'payment_proof' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,webp', 'max:5120'],
            'verification_notes' => ['nullable', 'string', 'max:255'],
            'ignore_quota' => ['nullable'],
            // Optional Member 2 for Ganda BLT
            'member2_name' => ['nullable', 'string', 'max:255'],
            'member2_nisn' => ['nullable', 'string', 'max:20'],
            'member2_school' => ['nullable', 'string', 'max:255'],
        ], [
            'competition_id.required' => 'Cabang lomba wajib dipilih.',
            'full_name.required' => 'Nama lengkap peserta wajib diisi.',
            'gender.required' => 'Jenis kelamin peserta wajib dipilih.',
            'institution_name.required' => 'Nama asal sekolah/madrasah wajib diisi.',
            'payment_method.required' => 'Metode pembayaran wajib dipilih (Tunai / Transfer).',
            'payment_proof.mimes' => 'Format berkas bukti pembayaran harus berupa JPG, PNG, atau PDF.',
            'payment_proof.max' => 'Ukuran berkas bukti pembayaran maksimal 5MB.',
        ]);

        $competition = Competition::findOrFail($validated['competition_id']);
        $this->authorizeCompetitionManagement($user, $competition->id);

        // Harmonize gender & category/match_type based on competition rules
        $gender = $validated['gender'];
        $matchType = $validated['match_type'] ?? null;
        $targetClass = $validated['target_class'] ?? null;
        $subCategory = null;

        if ($competition->code === 'BLT') {
            $isGanda = ! empty($matchType) && stripos($matchType, 'ganda') !== false;
            $isPutri = ! empty($matchType) && (stripos($matchType, 'putri') !== false || stripos($matchType, '(pi)') !== false);
            $isPutra = ! empty($matchType) && (stripos($matchType, 'putra') !== false || stripos($matchType, '(pa)') !== false);

            if ($isPutri) {
                $gender = 'P';
            } elseif ($isPutra) {
                $gender = 'L';
            }

            if ($isGanda) {
                $targetClass = 'Ganda (Semua Kelas)';
                $subCategory = $matchType;
            } else {
                if (empty($targetClass) || stripos($targetClass, 'ganda') !== false) {
                    $targetClass = 'Kategori A (Kelas 1 - 2)';
                }
                if (! empty($matchType)) {
                    $subCategory = $targetClass.' - '.$matchType;
                }
            }
        } elseif ($competition->code === 'TMJ') {
            $isPutri = ! empty($matchType) && (stripos($matchType, 'putri') !== false || stripos($matchType, '(pi)') !== false);
            $isPutra = ! empty($matchType) && (stripos($matchType, 'putra') !== false || stripos($matchType, '(pa)') !== false);

            if ($isPutri) {
                $gender = 'P';
            } elseif ($isPutra) {
                $gender = 'L';
            }

            if (! empty($targetClass) && ! empty($matchType)) {
                $subCategory = $targetClass.' - '.$matchType;
            } elseif (! empty($matchType)) {
                $subCategory = $matchType;
            }
        } elseif (in_array($competition->code, ['MTQ', 'POP'])) {
            $subCategory = ($gender === 'P') ? 'Putri (PI)' : 'Putra (PA)';
            $matchType = $subCategory;
        } elseif ($competition->isRobotik()) {
            if (! empty($matchType)) {
                if (stripos($matchType, 'Sumo') !== false) {
                    $subCategory = 'Robotik Sumo';
                    $matchType = 'Sumo';
                } elseif (stripos($matchType, 'Soccer') !== false) {
                    $subCategory = 'Robotik Soccer';
                    $matchType = 'Soccer';
                } elseif (stripos($matchType, 'Kreatif') !== false) {
                    $subCategory = 'Robotik Kreatif';
                    $matchType = 'Kreatif';
                }
            } else {
                $matchType = 'Kreatif';
                $subCategory = 'Robotik Kreatif';
            }
            $targetClass = $matchType;
        } elseif (! empty($targetClass) && ! empty($matchType)) {
            $subCategory = $targetClass.' - '.$matchType;
        } elseif (! empty($matchType)) {
            $subCategory = $matchType;
        }

        // Check quota if ignore_quota is not checked
        if (! $request->boolean('ignore_quota')) {
            if ($competition->quota > 0 && ! in_array($competition->code, ['BLT', 'TMJ'])) {
                $currentTotal = Registration::where('competition_id', $competition->id)
                    ->whereIn('status', ['pending', 'verified'])
                    ->count();
                if ($currentTotal >= $competition->quota) {
                    return back()->with('error', "Kuota pendaftaran untuk {$competition->name} sudah penuh ({$competition->quota} peserta). Centang opsi 'Abaikan Kuota' jika ini merupakan dispensasi khusus.")->withInput();
                }
            }
        }

        // Find or create User for the participant so they can login to portal if needed
        $nisnClean = ! empty($validated['nisn']) ? trim($validated['nisn']) : null;
        $participantUser = null;
        $isNewUser = false;
        if ($nisnClean) {
            $participantUser = User::where('nisn', $nisnClean)->first();
        }
        if (! $participantUser) {
            $randomSuffix = rand(100, 999);
            $autoNisn = $nisnClean ?: ('MNL'.date('ymd').$randomSuffix);
            $email = $autoNisn.'@peserta.talenta';
            if (User::where('email', $email)->exists()) {
                $email = $autoNisn.'_'.rand(10, 99).'@peserta.talenta';
            }
            $participantUser = User::create([
                'name' => $validated['full_name'],
                'nisn' => $nisnClean,
                'email' => $email,
                'password' => Hash::make($nisnClean ?: 'talenta2026'),
                'role' => 'peserta',
                'phone' => $validated['phone'] ?? null,
                'institution_name' => $validated['institution_name'],
                'account_type' => 'pendaftar',
                'status' => 'active',
            ]);
            $isNewUser = true;
        }

        // Prevent duplicate NISN in same competition / sector
        $nisnsToCheck = [];
        if ($nisnClean) {
            $nisnsToCheck[] = [
                'nisn' => $nisnClean,
                'name' => $validated['full_name'],
                'role' => 'Pemain 1 / Peserta Utama',
            ];
        }
        $member2NisnClean = ! empty($validated['member2_nisn']) ? trim($validated['member2_nisn']) : null;
        if ($member2NisnClean) {
            $nisnsToCheck[] = [
                'nisn' => $member2NisnClean,
                'name' => $validated['member2_name'] ?? 'Pemain 2',
                'role' => 'Pemain 2',
            ];
        }

        $isBltGanda = ($competition->code === 'BLT') && (! empty($matchType) && stripos($matchType, 'ganda') !== false);

        foreach ($nisnsToCheck as $item) {
            $existingMemberQuery = RegistrationMember::where('nisn', $item['nisn'])
                ->whereHas('registration', function ($q) use ($competition, $isBltGanda) {
                    $q->where('competition_id', $competition->id)
                        ->whereIn('status', ['pending', 'verified']);

                    if ($competition->code === 'BLT') {
                        if ($isBltGanda) {
                            $q->where(function ($sub) {
                                $sub->where('match_type', 'like', '%ganda%')
                                    ->orWhere('target_class', 'like', '%ganda%')
                                    ->orWhere('sub_category', 'like', '%ganda%');
                            });
                        } else {
                            $q->where(function ($sub) {
                                $sub->where(function ($s) {
                                    $s->whereNull('match_type')
                                        ->orWhere('match_type', 'not like', '%ganda%');
                                })->where(function ($s) {
                                    $s->whereNull('target_class')
                                        ->orWhere('target_class', 'not like', '%ganda%');
                                })->where(function ($s) {
                                    $s->whereNull('sub_category')
                                        ->orWhere('sub_category', 'not like', '%ganda%');
                                });
                            });
                        }
                    }
                });

            $existingMember = $existingMemberQuery->first();
            if ($existingMember) {
                $sectorText = ($competition->code === 'BLT') ? ('sektor '.($isBltGanda ? 'Ganda' : 'Tunggal').' ') : '';

                return back()->with('error', "Peserta ({$item['name']}) dengan NISN '{$item['nisn']}' sudah terdaftar pada {$sectorText}cabang {$competition->name}.")->withInput();
            }
        }

        // Store payment proof file
        $paymentProofPath = null;
        if ($request->hasFile('payment_proof')) {
            $paymentProofPath = ImageOptimizerService::storePaymentProof($request->file('payment_proof'), 'payments', 'pic_manual');
        }

        $regCode = 'REG-'.date('Y').'-'.$competition->code.'-'.strtoupper(Str::random(5));

        $teamName = null;
        if (! empty($validated['member2_name'])) {
            $teamName = $validated['full_name'].' / '.$validated['member2_name'];
        }

        $status = $validated['status'];
        $methodTag = $validated['payment_method'] === 'tunai' ? '[LUNAS TUNAI PIC: '.$user->name.']' : '[TRANSFER BANK: '.$user->name.']';
        $userNotes = ! empty($validated['verification_notes']) ? ' - '.$validated['verification_notes'] : '';
        $notes = $methodTag.$userNotes;

        $registration = Registration::create([
            'competition_id' => $competition->id,
            'user_id' => $participantUser->id,
            'registration_code' => $regCode,
            'team_name' => $teamName,
            'sub_category' => $subCategory,
            'chosen_song' => $request->input('chosen_song') ?: null,
            'target_class' => $targetClass,
            'match_type' => $matchType,
            'institution_name' => $validated['institution_name'],
            'official_name' => $user->name,
            'official_phone' => $validated['phone'] ?? $user->phone,
            'status' => $status,
            'payment_proof' => $paymentProofPath,
            'verified_at' => $status === 'verified' ? now() : null,
            'verified_by' => $status === 'verified' ? $user->id : null,
            'verification_notes' => $notes,
        ]);

        // Generate participant number if verified
        if ($status === 'verified') {
            $registration->generateParticipantNumber();
        }

        // Create Member 1
        RegistrationMember::create([
            'registration_id' => $registration->id,
            'full_name' => $validated['full_name'],
            'school_name' => $validated['institution_name'],
            'nisn' => $nisnClean,
            'gender' => $gender,
            'phone' => $validated['phone'] ?? null,
            'role_in_team' => ! empty($validated['member2_name']) ? 'Pemain 1' : 'Peserta Utama',
        ]);

        // Create Member 2 if Ganda
        if (! empty($validated['member2_name'])) {
            RegistrationMember::create([
                'registration_id' => $registration->id,
                'full_name' => $validated['member2_name'],
                'school_name' => $validated['member2_school'] ?: $validated['institution_name'],
                'nisn' => ! empty($validated['member2_nisn']) ? trim($validated['member2_nisn']) : null,
                'gender' => $gender,
                'role_in_team' => 'Pemain 2',
            ]);
        }

        ActivityLog::record(
            'MANUAL_REGISTRATION',
            "Mendaftarkan peserta baru '{$validated['full_name']}' secara manual pada cabang {$competition->name}".($status === 'verified' ? ' (Langsung Terverifikasi/Lunas Tunai)' : ' (Status: Pending)'),
            $user,
            'success'
        );

        // Trigger Auto WhatsApp Notifications for Manual Registration
        try {
            $registration->loadMissing(['members', 'user', 'competition']);
            $targetPhones = $registration->recipient_phones;
            if (empty($targetPhones) && ! empty($validated['phone'])) {
                $targetPhones = [$validated['phone']];
            }

            if (! empty($targetPhones)) {
                // 1. Notifikasi Akun Baru (jika dibuatkan akun baru)
                if ($isNewUser) {
                    WablasNotificationService::sendAutoNotification('account_created', [
                        'phone' => $targetPhones,
                        'nama_peserta' => $validated['full_name'],
                        'nisn' => $participantUser->nisn ?: $participantUser->email,
                        'nama_sekolah' => $validated['institution_name'],
                        'link_login' => route('login'),
                    ]);
                }

                // 2. Notifikasi Pendaftaran / Verifikasi ke Peserta & Official
                $memberNisns = $registration->members->pluck('nisn')->filter()->unique();
                $regNisn = $memberNisns->isNotEmpty() ? $memberNisns->implode(' / ') : ($nisnClean ?: ($participantUser->nisn ?: '-'));

                if ($status === 'verified') {
                    WablasNotificationService::sendAutoNotification('registration_verified', [
                        'phone' => $targetPhones,
                        'nama_peserta' => $validated['full_name'],
                        'nisn' => $regNisn,
                        'nama_sekolah' => $validated['institution_name'],
                        'cabang_lomba' => $competition->name,
                        'no_peserta' => $registration->participant_number ?: $registration->registration_code,
                        'kode_pendaftaran' => $registration->registration_code,
                        'link_scoreboard' => url('/'),
                        'link_login' => route('login'),
                    ]);
                } else {
                    WablasNotificationService::sendAutoNotification('registration_submitted', [
                        'phone' => $targetPhones,
                        'nama_peserta' => $validated['full_name'],
                        'nisn' => $regNisn,
                        'nama_sekolah' => $validated['institution_name'],
                        'cabang_lomba' => $competition->name,
                        'kode_pendaftaran' => $registration->registration_code,
                        'link_login' => route('login'),
                    ]);
                }
            }

            // 3. Notifikasi Alert ke Seluruh Petugas PIC Lomba
            WablasNotificationService::notifyPicNewRegistration($registration);

        } catch (\Throwable $e) {
            // Non-blocking
            Log::error('Gagal mengirim WhatsApp pendaftaran manual: '.$e->getMessage());
        }

        return redirect()->back()->with('success', "Peserta '{$validated['full_name']}' berhasil didaftarkan secara manual pada cabang {$competition->name}".($status === 'verified' ? ' dan langsung berstatus Lunas/Terverifikasi.' : '.'));
    }

    public function drawIndex()
    {
        $user = Auth::user();

        $competitions = Competition::with(['category', 'registrations' => function ($q) {
            $q->with('members');
        }])
            ->whereIn('id', self::getManagedCompetitionIds($user))
            ->get()
            ->map(function ($comp) {
                $verified = $comp->registrations->where('status', 'verified');
                $drawnCount = $verified->whereNotNull('draw_number')->count();
                $undrawnCount = $verified->whereNull('draw_number')->count();
                $totalVerified = $verified->count();

                return [
                    'id' => $comp->id,
                    'code' => $comp->code,
                    'name' => $comp->name,
                    'slug' => $comp->slug,
                    'category' => $comp->category->name ?? '-',
                    'total_registrations' => $comp->registrations->count(),
                    'total_verified' => $totalVerified,
                    'drawn_count' => $drawnCount,
                    'undrawn_count' => $undrawnCount,
                    'is_complete' => ($totalVerified > 0 && $undrawnCount === 0),
                ];
            });

        $totalDrawn = $competitions->sum('drawn_count');
        $totalUndrawn = $competitions->sum('undrawn_count');
        $totalVerifiedAll = $competitions->sum('total_verified');

        return view('pic.draw-index', compact('competitions', 'totalDrawn', 'totalUndrawn', 'totalVerifiedAll'));
    }

    public function hackerDraw($competition_id)
    {
        $user = Auth::user();
        $competition = Competition::with(['category', 'registrations' => function ($q) {
            $q->where('status', 'verified')->with('members');
        }])->findOrFail($competition_id);

        $this->authorizeCompetitionManagement($user, $competition->id);

        $pools = $this->buildCompetitionPools($competition);
        $verifiedList = collect($pools)->pluck('participants')->flatten(1)->values();
        $undrawnList = $verifiedList->where('is_drawn', false)->values();
        $drawnList = $verifiedList->where('is_drawn', true)->sortBy('draw_number')->values();

        return view('pic.hacker-draw', compact('competition', 'pools', 'verifiedList', 'undrawnList', 'drawnList'));
    }

    public function spinWheel($competition_id)
    {
        $user = Auth::user();
        $competition = Competition::with(['category', 'registrations' => function ($q) {
            $q->where('status', 'verified')->with('members');
        }])->findOrFail($competition_id);

        $this->authorizeCompetitionManagement($user, $competition->id);

        $pools = $this->buildCompetitionPools($competition);
        $verifiedList = collect($pools)->pluck('participants')->flatten(1)->values();
        $undrawnList = $verifiedList->where('is_drawn', false)->values();
        $drawnList = $verifiedList->where('is_drawn', true)->sortBy('draw_number')->values();

        return view('pic.spin-wheel', compact('competition', 'pools', 'verifiedList', 'undrawnList', 'drawnList'));
    }

    protected function buildCompetitionPools(Competition $competition): array
    {
        $compCode = strtoupper($competition->code ?? '');
        $isBuluTangkis = ($compCode === 'BLT' || stripos($competition->name, 'bulu tangkis') !== false || stripos($competition->name, 'badminton') !== false);
        $isTenisMeja = ($compCode === 'TMJ' || stripos($competition->name, 'tenis meja') !== false || stripos($competition->name, 'pingpong') !== false);
        $isRobotik = method_exists($competition, 'isRobotik') ? $competition->isRobotik() : ($compCode === 'ROB' || stripos($competition->name, 'robot') !== false);

        $registrations = $competition->registrations;
        $classified = [];

        if ($isBuluTangkis) {
            $poolDefs = [
                'kat_a_pa' => ['name' => 'Kategori A (Kelas 1–2) - Tunggal Putra (PA)', 'label' => 'Kategori A (Kelas 1–2)', 'short' => '👦 Kat A (1-2) Putra', 'gender' => 'L', 'sector' => 'PA', 'type' => 'kat_a', 'ganda' => false],
                'kat_a_pi' => ['name' => 'Kategori A (Kelas 1–2) - Tunggal Putri (PI)', 'label' => 'Kategori A (Kelas 1–2)', 'short' => '👧 Kat A (1-2) Putri', 'gender' => 'P', 'sector' => 'PI', 'type' => 'kat_a', 'ganda' => false],
                'kat_b_pa' => ['name' => 'Kategori B (Kelas 3–4) - Tunggal Putra (PA)', 'label' => 'Kategori B (Kelas 3–4)', 'short' => '👦 Kat B (3-4) Putra', 'gender' => 'L', 'sector' => 'PA', 'type' => 'kat_b', 'ganda' => false],
                'kat_b_pi' => ['name' => 'Kategori B (Kelas 3–4) - Tunggal Putri (PI)', 'label' => 'Kategori B (Kelas 3–4)', 'short' => '👧 Kat B (3-4) Putri', 'gender' => 'P', 'sector' => 'PI', 'type' => 'kat_b', 'ganda' => false],
                'kat_c_pa' => ['name' => 'Kategori C (Kelas 5–6) - Tunggal Putra (PA)', 'label' => 'Kategori C (Kelas 5–6)', 'short' => '👦 Kat C (5-6) Putra', 'gender' => 'L', 'sector' => 'PA', 'type' => 'kat_c', 'ganda' => false],
                'kat_c_pi' => ['name' => 'Kategori C (Kelas 5–6) - Tunggal Putri (PI)', 'label' => 'Kategori C (Kelas 5–6)', 'short' => '👧 Kat C (5-6) Putri', 'gender' => 'P', 'sector' => 'PI', 'type' => 'kat_c', 'ganda' => false],
                'ganda_pa' => ['name' => 'Ganda Putra (PA) - Semua Kelas', 'label' => 'Ganda (Semua Kelas)', 'short' => '👥 Ganda Putra', 'gender' => 'L', 'sector' => 'PA', 'type' => 'ganda', 'ganda' => true],
                'ganda_pi' => ['name' => 'Ganda Putri (PI) - Semua Kelas', 'label' => 'Ganda (Semua Kelas)', 'short' => '👥 Ganda Putri', 'gender' => 'P', 'sector' => 'PI', 'type' => 'ganda', 'ganda' => true],
                'ganda_mix' => ['name' => 'Ganda Campuran - Semua Kelas', 'label' => 'Ganda (Semua Kelas)', 'short' => '👥 Ganda Campuran', 'gender' => 'M', 'sector' => 'MIX', 'type' => 'ganda', 'ganda' => true],
            ];

            foreach ($poolDefs as $key => $def) {
                $poolRegs = $registrations->filter(function ($reg) use ($def) {
                    $isGanda = $reg->isGanda() || stripos($reg->target_class ?? '', 'ganda') !== false;
                    if ($def['ganda']) {
                        if (! $isGanda) {
                            return false;
                        }
                    } else {
                        if ($isGanda) {
                            return false;
                        }
                        if ($def['type'] === 'kat_a' && ! $reg->isKatA()) {
                            return false;
                        }
                        if ($def['type'] === 'kat_b' && ! $reg->isKatB()) {
                            return false;
                        }
                        if ($def['type'] === 'kat_c' && ! $reg->isKatC()) {
                            return false;
                        }
                    }

                    $gen = $reg->primary_gender;
                    if ($def['gender'] === 'M') {
                        return $gen === 'M' || stripos($reg->match_type ?? '', 'campuran') !== false;
                    } elseif ($def['gender'] === 'P') {
                        return $gen === 'P' || stripos($reg->match_type ?? '', 'putri') !== false || stripos($reg->match_type ?? '', 'pi') !== false;
                    } else {
                        return $gen === 'L' || stripos($reg->match_type ?? '', 'putra') !== false || stripos($reg->match_type ?? '', 'pa') !== false || ($gen !== 'P' && $gen !== 'M' && stripos($reg->match_type ?? '', 'putri') === false && stripos($reg->match_type ?? '', 'campuran') === false);
                    }
                });

                if ($poolRegs->isNotEmpty()) {
                    $classified[$key] = [
                        'key' => $key,
                        'title' => $def['name'],
                        'class_key' => $def['type'] ?? 'all',
                        'class_label' => $def['label'] ?? $def['name'],
                        'category_label' => $def['label'] ?? $def['name'],
                        'short_title' => $def['short'],
                        'gender' => $def['gender'] ?? 'L',
                        'sector' => $def['sector'] ?? (($def['gender'] ?? 'L') === 'P' ? 'PI' : 'PA'),
                        'participants' => $this->formatParticipantList($poolRegs),
                    ];
                }
            }
        } elseif ($isTenisMeja) {
            $poolDefs = [
                'kat_a_pa' => ['name' => 'Kategori A (Kelas 1–3) - Tunggal Putra (PA)', 'label' => 'Kategori A (Kelas 1–3)', 'short' => '👦 Kat A (1-3) Putra', 'gender' => 'L', 'sector' => 'PA', 'type' => 'kat_a', 'ganda' => false],
                'kat_a_pi' => ['name' => 'Kategori A (Kelas 1–3) - Tunggal Putri (PI)', 'label' => 'Kategori A (Kelas 1–3)', 'short' => '👧 Kat A (1-3) Putri', 'gender' => 'P', 'sector' => 'PI', 'type' => 'kat_a', 'ganda' => false],
                'kat_b_pa' => ['name' => 'Kategori B (Kelas 4–6) - Tunggal Putra (PA)', 'label' => 'Kategori B (Kelas 4–6)', 'short' => '👦 Kat B (4-6) Putra', 'gender' => 'L', 'sector' => 'PA', 'type' => 'kat_b', 'ganda' => false],
                'kat_b_pi' => ['name' => 'Kategori B (Kelas 4–6) - Tunggal Putri (PI)', 'label' => 'Kategori B (Kelas 4–6)', 'short' => '👧 Kat B (4-6) Putri', 'gender' => 'P', 'sector' => 'PI', 'type' => 'kat_b', 'ganda' => false],
            ];

            foreach ($poolDefs as $key => $def) {
                $poolRegs = $registrations->filter(function ($reg) use ($def) {
                    if ($def['type'] === 'kat_a' && ! $reg->isKatA()) {
                        return false;
                    }
                    if ($def['type'] === 'kat_b' && ! $reg->isKatB()) {
                        return false;
                    }

                    $gen = $reg->primary_gender;
                    if ($def['gender'] === 'P') {
                        return $gen === 'P' || stripos($reg->match_type ?? '', 'Putri') !== false || stripos($reg->match_type ?? '', 'PI') !== false;
                    } else {
                        return $gen === 'L' || stripos($reg->match_type ?? '', 'Putra') !== false || stripos($reg->match_type ?? '', 'PA') !== false || ($gen !== 'P' && stripos($reg->match_type ?? '', 'Putri') === false && stripos($reg->match_type ?? '', 'PI') === false);
                    }
                });

                if ($poolRegs->isNotEmpty()) {
                    $classified[$key] = [
                        'key' => $key,
                        'title' => $def['name'],
                        'class_key' => $def['type'] ?? 'all',
                        'class_label' => $def['label'] ?? $def['name'],
                        'category_label' => $def['label'] ?? $def['name'],
                        'short_title' => $def['short'],
                        'gender' => $def['gender'] ?? 'L',
                        'sector' => $def['sector'] ?? (($def['gender'] ?? 'L') === 'P' ? 'PI' : 'PA'),
                        'participants' => $this->formatParticipantList($poolRegs),
                    ];
                }
            }
        } elseif ($isRobotik) {
            $poolDefs = [
                'rob_sumo' => ['name' => 'Robotik - Sumo', 'label' => 'Robotik Sumo', 'short' => '🤖 Sumo', 'category' => 'Sumo'],
                'rob_soccer' => ['name' => 'Robotik - Soccer', 'label' => 'Robotik Soccer', 'short' => '⚽ Soccer', 'category' => 'Soccer'],
                'rob_kreatif' => ['name' => 'Robotik - Kreatif', 'label' => 'Robotik Kreatif', 'short' => '💡 Kreatif', 'category' => 'Kreatif'],
            ];

            foreach ($poolDefs as $key => $def) {
                $poolRegs = $registrations->filter(function ($reg) use ($def) {
                    $cat = $def['category'];

                    return stripos($reg->match_type ?? '', $cat) !== false
                        || stripos($reg->sub_category ?? '', $cat) !== false
                        || stripos($reg->target_class ?? '', $cat) !== false;
                });

                if ($poolRegs->isNotEmpty()) {
                    $classified[$key] = [
                        'key' => $key,
                        'title' => $def['name'],
                        'class_key' => $key,
                        'class_label' => $def['label'],
                        'category_label' => $def['label'],
                        'short_title' => $def['short'],
                        'gender' => 'ALL',
                        'sector' => strtoupper($def['category']),
                        'participants' => $this->formatParticipantList($poolRegs),
                    ];
                }
            }
        }

        // Check for any unmatched registrations (fallback safe guarantee)
        $matchedIds = collect($classified)->pluck('participants')->flatten(1)->pluck('id')->toArray();
        $unmatched = $registrations->whereNotIn('id', $matchedIds);

        if ($unmatched->isNotEmpty()) {
            if (empty($classified)) {
                // If it's another competition, check PA / PI
                $paRegs = $unmatched->filter(fn ($r) => $r->primary_gender === 'L' || stripos($r->match_type ?? '', 'Putra') !== false);
                $piRegs = $unmatched->filter(fn ($r) => $r->primary_gender === 'P' || stripos($r->match_type ?? '', 'Putri') !== false);

                if ($paRegs->isNotEmpty() && $piRegs->isNotEmpty()) {
                    $classified['pa'] = [
                        'key' => 'pa',
                        'title' => 'Kelompok Putra (PA)',
                        'class_key' => 'all',
                        'class_label' => 'Semua Kelas',
                        'category_label' => 'Putra (PA)',
                        'short_title' => '👦 Putra (PA)',
                        'gender' => 'L',
                        'sector' => 'PA',
                        'participants' => $this->formatParticipantList($paRegs),
                    ];
                    $classified['pi'] = [
                        'key' => 'pi',
                        'title' => 'Kelompok Putri (PI)',
                        'class_key' => 'all',
                        'class_label' => 'Semua Kelas',
                        'category_label' => 'Putri (PI)',
                        'short_title' => '👧 Putri (PI)',
                        'gender' => 'P',
                        'sector' => 'PI',
                        'participants' => $this->formatParticipantList($piRegs),
                    ];
                } else {
                    $classified['all'] = [
                        'key' => 'all',
                        'title' => 'Semua Peserta',
                        'short_title' => '👥 Semua Peserta',
                        'participants' => $this->formatParticipantList($unmatched),
                    ];
                }
            } else {
                // Append remaining as other
                $classified['other'] = [
                    'key' => 'other',
                    'title' => 'Peserta Lainnya',
                    'short_title' => '👥 Lainnya ('.$unmatched->count().')',
                    'participants' => $this->formatParticipantList($unmatched),
                ];
            }
        }

        return array_values($classified);
    }

    protected function formatParticipantList($regs): array
    {
        return $regs->map(function ($reg) {
            $firstMember = $reg->members->first();
            $pureName = $reg->team_name ?: ($firstMember?->full_name ?: 'Peserta #'.$reg->id);

            return [
                'id' => $reg->id,
                'name' => $pureName,
                'institution' => $reg->institution_name,
                'participant_number' => $reg->participant_number,
                'registration_code' => $reg->registration_code,
                'target_class' => $reg->target_class,
                'match_type' => $reg->match_type,
                'gender' => $reg->primary_gender,
                'draw_number' => $reg->draw_number,
                'is_drawn' => ! is_null($reg->draw_number),
                'seed_number' => $reg->seed_number,
                'is_seeded' => $reg->isSeeded(),
                'seed_label' => $reg->seed_label,
            ];
        })->values()->toArray();
    }

    public function setSeededPlayers(Request $request, $competition_id)
    {
        $competition = Competition::with(['category', 'registrations.members'])->findOrFail($competition_id);
        $user = Auth::user();
        $this->authorizeCompetitionManagement($user, $competition->id);

        $validated = $request->validate([
            'pool_key' => ['required', 'string'],
            'seeds' => ['present', 'array'],
            'seeds.*' => ['nullable', 'integer', 'min:1', 'max:16'],
        ]);

        $pools = $this->buildCompetitionPools($competition);
        $targetPool = collect($pools)->firstWhere('key', $validated['pool_key']);

        if (! $targetPool) {
            return response()->json([
                'success' => false,
                'message' => 'Kategori / Pool tidak ditemukan.',
            ], 404);
        }

        $poolParticipantIds = collect($targetPool['participants'])->pluck('id')->map(fn ($id) => (int) $id)->toArray();
        $totalInPool = count($poolParticipantIds);

        // Sanity check: ensure each seed number is assigned at most once
        $assignedSeeds = [];
        $seedMap = [];
        foreach ($validated['seeds'] as $regId => $seedNum) {
            $regId = (int) $regId;
            $seedNum = ! empty($seedNum) ? (int) $seedNum : null;

            if ($seedNum && in_array($regId, $poolParticipantIds, true)) {
                if (in_array($seedNum, $assignedSeeds, true)) {
                    return response()->json([
                        'success' => false,
                        'message' => "Posisi Seed {$seedNum} tidak boleh diberikan ke lebih dari satu peserta.",
                    ], 422);
                }
                $assignedSeeds[] = $seedNum;
                $seedMap[$regId] = $seedNum;
            }
        }

        // Process each participant in this pool
        DB::transaction(function () use ($poolParticipantIds, $seedMap, $totalInPool, $competition, $user) {
            // Sort seeds ascending so Seed 1 gets its slot first, then 2, 3, 4, 5, etc.
            asort($seedMap);
            $allocatedSlots = [];

            foreach ($seedMap as $regId => $seedNum) {
                $reg = Registration::where('id', $regId)
                    ->where('competition_id', $competition->id)
                    ->first();

                if (! $reg) {
                    continue;
                }

                $fixedSlot = $this->calculateSeedSlot($seedNum, $totalInPool, $allocatedSlots);
                $allocatedSlots[$regId] = $fixedSlot;

                // If another participant in the same pool currently holds this slot, clear them
                Registration::where('competition_id', $competition->id)
                    ->whereIn('id', $poolParticipantIds)
                    ->where('id', '!=', $reg->id)
                    ->where('draw_number', $fixedSlot)
                    ->update(['draw_number' => null, 'seed_number' => null]);

                DrawAllocation::where('competition_id', $competition->id)
                    ->whereIn('registration_id', $poolParticipantIds)
                    ->where('registration_id', '!=', $reg->id)
                    ->where('draw_number', $fixedSlot)
                    ->delete();

                $reg->seed_number = $seedNum;
                $reg->draw_number = $fixedSlot;
                $reg->save();

                DrawAllocation::updateOrCreate(
                    [
                        'competition_id' => $competition->id,
                        'registration_id' => $reg->id,
                    ],
                    [
                        'draw_number' => $fixedSlot,
                        'spun_at' => now(),
                        'spun_by' => $user->id,
                    ]
                );
            }

            // For participants in this pool that are NOT in seedMap:
            foreach ($poolParticipantIds as $regId) {
                if (! isset($seedMap[$regId])) {
                    $reg = Registration::where('id', $regId)
                        ->where('competition_id', $competition->id)
                        ->first();

                    if ($reg && $reg->seed_number !== null) {
                        $reg->seed_number = null;
                        $reg->draw_number = null;
                        $reg->save();

                        DrawAllocation::where('competition_id', $competition->id)
                            ->where('registration_id', $reg->id)
                            ->delete();
                    }
                }
            }
        });

        // Reload fresh competition data
        $competition->refresh();
        $competition->load(['category', 'registrations.members']);
        $updatedPools = $this->buildCompetitionPools($competition);

        return response()->json([
            'success' => true,
            'message' => 'Pengaturan pemain unggulan (seeded) berhasil disimpan!',
            'pools' => $updatedPools,
        ]);
    }

    protected function calculateSeedSlot(int $seed, int $totalParticipants, array $usedSlots = []): int
    {
        if ($totalParticipants <= 1) {
            return 1;
        }

        $baseSlot = match ($seed) {
            1 => 1,
            2 => $totalParticipants,
            3 => (int) floor($totalParticipants / 2) + 1,
            4 => (int) floor($totalParticipants / 2),
            5 => (int) floor($totalParticipants / 4) + 1,
            6 => (int) floor(3 * $totalParticipants / 4),
            7 => (int) floor(3 * $totalParticipants / 4) + 1,
            8 => (int) floor($totalParticipants / 4),
            default => min($seed, $totalParticipants),
        };

        $baseSlot = max(1, min($totalParticipants, $baseSlot));

        if (in_array($baseSlot, $usedSlots, true)) {
            for ($offset = 1; $offset < $totalParticipants; $offset++) {
                if ($baseSlot + $offset <= $totalParticipants && ! in_array($baseSlot + $offset, $usedSlots, true)) {
                    return $baseSlot + $offset;
                }
                if ($baseSlot - $offset >= 1 && ! in_array($baseSlot - $offset, $usedSlots, true)) {
                    return $baseSlot - $offset;
                }
            }
        }

        return $baseSlot;
    }

    public function storeDrawResult(Request $request, $competition_id)
    {
        $competition = Competition::findOrFail($competition_id);
        $user = Auth::user();
        $this->authorizeCompetitionManagement($user, $competition->id);

        $validated = $request->validate([
            'registration_id' => ['required', 'exists:registrations,id'],
            'draw_number' => ['required', 'integer', 'min:1'],
        ]);

        $registration = Registration::where('id', $validated['registration_id'])
            ->where('competition_id', $competition->id)
            ->firstOrFail();

        $registration->draw_number = $validated['draw_number'];
        $registration->save();

        DrawAllocation::updateOrCreate(
            [
                'competition_id' => $competition->id,
                'registration_id' => $registration->id,
            ],
            [
                'draw_number' => $validated['draw_number'],
                'spun_at' => now(),
                'spun_by' => $user->id,
            ]
        );

        // Trigger Auto WhatsApp Notification: Hasil Undian Spin Wheel / Hacker Draw
        try {
            $registration->loadMissing(['members', 'user', 'competition']);
            $memberNisns = $registration->members->pluck('nisn')->filter()->unique();
            $nisn = $memberNisns->isNotEmpty() ? $memberNisns->implode(' / ') : ($registration->user?->nisn ?? '-');
            $targetPhones = $registration->recipient_phones;

            WablasNotificationService::sendAutoNotification('draw_result_picked', [
                'phone' => $targetPhones,
                'nama_peserta' => $registration->pure_name,
                'nisn' => $nisn,
                'nama_sekolah' => $registration->institution_name,
                'cabang_lomba' => $competition->name,
                'no_peserta' => $registration->participant_number ?: $registration->registration_code,
                'kode_pendaftaran' => $registration->registration_code,
                'nomor_undian' => $validated['draw_number'],
                'draw_number' => $validated['draw_number'],
                'link_scoreboard' => url('/'),
                'link_login' => route('login'),
            ]);
        } catch (\Throwable $e) {
            // Non-blocking
        }

        return response()->json([
            'success' => true,
            'message' => 'Nomor undian '.$validated['draw_number'].' berhasil disimpan untuk '.$registration->display_name,
            'registration' => $registration,
        ]);
    }

    public function batchAutoDraw(Request $request, $competition_id)
    {
        $competition = Competition::with(['category', 'registrations' => function ($q) {
            $q->where('status', 'verified')->with('members');
        }])->findOrFail($competition_id);

        $user = Auth::user();
        $this->authorizeCompetitionManagement($user, $competition->id);

        $poolKey = $request->input('pool_key');
        $pools = $this->buildCompetitionPools($competition);

        // Determine target pools
        $targetPools = [];
        if (! empty($poolKey) && $poolKey !== 'all') {
            $selected = collect($pools)->firstWhere('key', $poolKey);
            if (! $selected) {
                return response()->json([
                    'success' => false,
                    'message' => 'Kategori / Pool tidak ditemukan.',
                ], 404);
            }
            $targetPools[] = $selected;
        } else {
            $targetPools = $pools;
        }

        $allDrawnResults = [];
        $totalNewlyDrawn = 0;

        DB::transaction(function () use ($targetPools, $competition, $user, &$allDrawnResults, &$totalNewlyDrawn) {
            foreach ($targetPools as $pool) {
                $poolParticipants = $pool['participants'];
                $totalInPool = count($poolParticipants);

                if ($totalInPool === 0) {
                    continue;
                }

                // Get IDs of already drawn participants and used draw numbers
                $usedSlots = collect($poolParticipants)
                    ->where('is_drawn', true)
                    ->pluck('draw_number')
                    ->filter()
                    ->map(fn ($n) => (int) $n)
                    ->toArray();

                // Undrawn participants in this pool
                $undrawn = collect($poolParticipants)
                    ->where('is_drawn', false)
                    ->values();

                if ($undrawn->isEmpty()) {
                    continue;
                }

                // Available slots in range 1..totalInPool not yet taken
                $availableSlots = [];
                for ($slot = 1; $slot <= $totalInPool; $slot++) {
                    if (! in_array($slot, $usedSlots, true)) {
                        $availableSlots[] = $slot;
                    }
                }

                // Shuffle available slots cryptographically / Fisher-Yates
                shuffle($availableSlots);

                foreach ($undrawn as $participantData) {
                    if (empty($availableSlots)) {
                        break;
                    }

                    $assignedSlot = array_shift($availableSlots);

                    $reg = Registration::where('id', $participantData['id'])
                        ->where('competition_id', $competition->id)
                        ->first();

                    if ($reg) {
                        $reg->draw_number = $assignedSlot;
                        $reg->save();

                        DrawAllocation::updateOrCreate(
                            [
                                'competition_id' => $competition->id,
                                'registration_id' => $reg->id,
                            ],
                            [
                                'draw_number' => $assignedSlot,
                                'spun_at' => now(),
                                'spun_by' => $user->id,
                            ]
                        );

                        $allDrawnResults[] = [
                            'id' => $reg->id,
                            'draw_number' => $assignedSlot,
                            'name' => $participantData['name'],
                            'institution' => $participantData['institution'],
                            'pool_key' => $pool['key'],
                        ];

                        $totalNewlyDrawn++;
                    }
                }
            }
        });

        if ($totalNewlyDrawn === 0) {
            return response()->json([
                'success' => false,
                'message' => 'Semua peserta pada kategori ini sudah memiliki nomor undian.',
            ], 422);
        }

        // Trigger Auto WhatsApp Notification for all newly drawn participants (non-blocking)
        try {
            $regIds = collect($allDrawnResults)->pluck('id')->toArray();
            $registrations = Registration::whereIn('id', $regIds)->with(['members', 'user', 'competition'])->get();

            foreach ($registrations as $reg) {
                $memberNisns = $reg->members->pluck('nisn')->filter()->unique();
                $nisn = $memberNisns->isNotEmpty() ? $memberNisns->implode(' / ') : ($reg->user?->nisn ?? '-');
                $targetPhones = $reg->recipient_phones;

                WablasNotificationService::sendAutoNotification('draw_result_picked', [
                    'phone' => $targetPhones,
                    'nama_peserta' => $reg->pure_name,
                    'nisn' => $nisn,
                    'nama_sekolah' => $reg->institution_name,
                    'cabang_lomba' => $competition->name,
                    'no_peserta' => $reg->participant_number ?: $reg->registration_code,
                    'kode_pendaftaran' => $reg->registration_code,
                    'nomor_undian' => $reg->draw_number,
                    'draw_number' => $reg->draw_number,
                    'link_scoreboard' => url('/'),
                    'link_login' => route('login'),
                ]);
            }
        } catch (\Throwable $e) {
            // Non-blocking
        }

        return response()->json([
            'success' => true,
            'message' => 'Berhasil mengacak '.$totalNewlyDrawn.' peserta secara serentak via Batch / Full-Shuffle Auto Draw.',
            'drawn_count' => $totalNewlyDrawn,
            'results' => $allDrawnResults,
        ]);
    }

    public function resetDraws(Request $request, $competition_id)
    {
        $competition = Competition::findOrFail($competition_id);
        $user = Auth::user();
        $this->authorizeCompetitionManagement($user, $competition->id);

        $adminPassword = $request->input('admin_password');
        if (empty($adminPassword)) {
            $errMsg = 'Password admin wajib diisi untuk melakukan reset undian.';
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json(['success' => false, 'message' => $errMsg], 422);
            }

            return back()->with('error', $errMsg);
        }

        // Cek kecocokan password: user login saat ini atau superadmin
        $isPasswordValid = false;
        if ($user && Hash::check($adminPassword, $user->password)) {
            $isPasswordValid = true;
        } else {
            $superAdmins = User::where('role', 'superadmin')->get();
            foreach ($superAdmins as $sa) {
                if (Hash::check($adminPassword, $sa->password)) {
                    $isPasswordValid = true;
                    break;
                }
            }
        }

        if (! $isPasswordValid) {
            $errMsg = 'Password admin salah! Proses reset undian dibatalkan.';
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json(['success' => false, 'message' => $errMsg], 403);
            }

            return back()->with('error', $errMsg);
        }

        $regIds = $request->input('registration_ids');
        if (! empty($regIds)) {
            if (is_string($regIds)) {
                $regIds = array_filter(explode(',', $regIds));
            }
            Registration::where('competition_id', $competition->id)->whereIn('id', $regIds)->update(['draw_number' => null, 'seed_number' => null]);
            DrawAllocation::where('competition_id', $competition->id)->whereIn('registration_id', $regIds)->delete();

            $msg = 'Nomor undian untuk kategori terpilih pada '.$competition->name.' berhasil di-reset.';
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json(['success' => true, 'message' => $msg]);
            }

            return back()->with('success', $msg);
        }

        Registration::where('competition_id', $competition->id)->update(['draw_number' => null, 'seed_number' => null]);
        DrawAllocation::where('competition_id', $competition->id)->delete();

        $msg = 'Semua nomor undian pada cabang '.$competition->name.' telah di-reset.';
        if ($request->expectsJson() || $request->ajax()) {
            return response()->json(['success' => true, 'message' => $msg]);
        }

        return back()->with('success', $msg);
    }
}
